﻿using System;

namespace Nakljucna_stevila
{
    class Program
    {
        static void Main(string[] args)
        {
            // Random aa = new Random(); // naredimo objekt
            //int a = aa.Next(1, 1000);
            int a = new Random().Next(1, 1000);
            Console.WriteLine(a);


        }
    }
}
