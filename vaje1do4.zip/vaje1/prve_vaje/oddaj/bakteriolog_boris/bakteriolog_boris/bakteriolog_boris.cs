﻿using System;

namespace bakteriolog_boris
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Vnesi maso v regiji A: ");
            double masaA = double.Parse(Console.ReadLine());
            Console.Write("Vnesi maso v regiji B: ");
            double masaB = double.Parse(Console.ReadLine());
            int korak = 0;
            while(masaA + masaB >= 0.001)
            {
                Console.WriteLine($"{korak}, {masaA}, {masaB}");
                double mA = masaA * 0.22;
                double mB = masaB * 0.22;
                masaA = masaA * 0.12 + mB;
                masaB = masaB * 0.12 + mA;
                
                
                korak += 1;

            }
        }
    }
}
