﻿using System;

namespace obrati
{
    class Program
    {
        static void Main(string[] args)
        {
            /*Preberi dve pozitivni tromestni celi števili in izpiši razliko obrnjenih števil (z računom vred). Če preberemo 231 in 702, izpišemo*/
            int a = int.Parse(Console.ReadLine());
            int b = int.Parse(Console.ReadLine()); //preberm tromestno število
            // število razdelim

            int a1 = a / 100;
            int a2 = (a / 10) % 10;
            int a3 = a % 10;
            int b1 = b / 100;
            int b2 = (b / 10) % 10;
            int b3 = b % 10;

            Console.WriteLine($"{a3 * 100 + a2 * 10 + a1} - {b3 * 100 + b2 * 10 + b1} = {(a3 * 100 + a2 * 10 + a1) - (b3 * 100 + b2 * 10 + b1)}" );
        }
    }
}
