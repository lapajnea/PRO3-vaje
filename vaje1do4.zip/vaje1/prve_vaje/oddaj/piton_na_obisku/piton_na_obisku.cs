﻿using System;

namespace piton_na_obisku
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Vnesi n: ");
            int n = int.Parse(Console.ReadLine());
            Console.Write("Vnesi k: ");

            int k = int.Parse(Console.ReadLine());

            int vsota = 0;

            for (int i = 0; i < n + 1; i++)
            {
                vsota +=  (int)Math.Pow(i, k);
            }
            Console.WriteLine($"rezultat = {vsota}");

        }
    }
}
