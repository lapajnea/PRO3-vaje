﻿using System;

namespace vaja1
{
    class Program
    {
        static void Main(string[] arg)  // spremeniti iz public v static
        {
            int a = int.Parse(Console.ReadLine());  // določiti tip spremenljivk in jih spermeniti v int, da bomo z njimi račualni
            int b = int.Parse(Console.ReadLine());
            int c = int.Parse(Console.ReadLine());
 
            Console.WriteLine($"Za števila a, b in c seveda velja a+(b+c)=(a+b)+c, saj je {(a + ( b + c ))} = {( a + b ) + c }.");
            // izpisovali s pomočjo $
        }
    }
    }

