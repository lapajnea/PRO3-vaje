﻿using System;

namespace vaje
{
    class Program
    {
        static void Main(string[] args)
        {
            int imam = 10 , rabim = 20, vrecka= 40;
            // koliko vreck kosmicev je potrebno še kupiti
            if (imam > rabim)
            {
                Console.WriteLine(0);
            }
            else
            {
                if ((rabim - imam) % vrecka == 0)
                { Console.WriteLine(rabim - vrecka); }
                else
                {
                    Console.WriteLine((rabim - imam) / vrecka + 1);
                }
            }

            while (imam < 10){
                Console.WriteLine(imam);
                imam++;
            }

            
        }
    }
}
