﻿using System;
using Humanizer;

//Console.WriteLine("Vnesi niz: ");
string beri = Console.ReadLine();
string obrnjen = "";

int dolzina = beri.Length;
int kje = 0;
//obrnemo niz
while (kje < dolzina)
{
    obrnjen = beri[kje] + obrnjen;
    kje++;
}
//Console.WriteLine($"Niz {beri} je obrnjen {obrnjen}.");



int x = 123;
Console.WriteLine(x.ToWords());