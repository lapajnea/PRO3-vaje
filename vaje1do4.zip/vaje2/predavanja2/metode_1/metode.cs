﻿using System;


/// <summary>
/// 
/// </summary>
public static int Max(int a, int b)
{
    return 42;
}