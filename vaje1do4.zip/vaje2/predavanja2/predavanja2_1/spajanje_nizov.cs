﻿using System;
//iz znaka v niz
char znak = 'm';
string bla = "m";
string t;
Console.WriteLine(znak + 0);
Console.WriteLine(znak + 1);
Console.WriteLine(bla +"" ); //spajanje dveh nizov ??

