﻿string niz = "bla";
string niz2 = niz.Substring(0, 2) + niz[2] + 0; // najprej se izvede + (niz  + nekej kar je tipa char -> niz + 'a' => 'bla' + nekej kar je tipa int => "bla0"

string niz3 = niz.Substring(0, 2) + (niz[2] + 0); // če gledamo znak kot znak, dobimo njegovo kodo (mesto nahajanja)
System.Console.WriteLine($"{niz2} : {niz3}");
