﻿using System;
    
int[] tab = new int[10];
tab[0] = 12;
Console.WriteLine(tab);
