﻿using System;

namespace metoda_najmanjsi
{
    internal class metoda_najmanjsi
    {
        /// <summary>
        /// V tabeli zamenja prvi in najmanjsi element
        /// </summary>
        public static void NajmanjsiNaZacetek(int[] tab)
        {
            if (tab.Length == 0)
            {
                throw new Exception("Tabela ima dolžino 0!");
            } // ni treba dat v zavite oklepaje, ker imam samo en stavek

            //poiščemo mesto najmanjšega elementa
            int kjeNajm = 0;
            int najm = tab[0];
            //pregledamo tabelo
            for (int i = 1; i < tab.Length; i++)
            {
                if (tab[i] < najm)
                {
                    kjeNajm = i;
                    najm = tab[i];
                }
            }
            //zamenjamo prvega in kje najmanjsu
            int temp = tab[0];
            tab[0] = tab[kjeNajm];
            tab[kjeNajm] = temp;

        }
        static void Main(string[] args) 
        {
        }
    }
}
