﻿using System;

namespace sibice
{
    class sibice
    {
        static void Main(string[] args)
        {
            string[] stevila = Console.ReadLine().Split(' '); //ločimo jih po presledku 
            int primeri = int.Parse(stevila[0]);
            double a = Math.Sqrt(Math.Pow(int.Parse(stevila[1]), 2) + Math.Pow(int.Parse(stevila[2]), 2));
            for (int i = 0; i < stevila.Length; i++)
            {
                if (primeri[i] < a)
                {
                    Console.Write("DA");
                }
                else
                    Console.Write("NE");
            }
        }
    }
}
