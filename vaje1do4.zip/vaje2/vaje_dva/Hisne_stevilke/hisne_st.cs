﻿using System;

namespace Hisne_stevilke
{
    class HisneStevilke
    {


        static void Main(string[] args)
        {
            Console.Write("Vnesi prvo številko: ");
            int prva = int.Parse(Console.ReadLine());
            Console.Write("Vnesi zadnjo številko: ");
            int zadnja = int.Parse(Console.ReadLine());

            int[] potrebe = Potrebe(prva, zadnja);

            for (int i = 0; i < 10; i++)
            {
                Console.WriteLine($"{i}: {potrebe[i]}x");
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="prva"></param>
        /// <param name="zadnja"></param>
        /// <returns>return int[]</returns>
        public static int[] Potrebe(int prva, int zadnja)
        {
            int[] posamezna = new int[10];

            for (int i = prva; i <= zadnja; i++)
            {
                int st = i;
                while (st > 0)
                {
                    int stevka = st % 10;
                    posamezna[stevka]++;
                    st /= 10;
                }
            }

            return posamezna;
        }
        
    }
}