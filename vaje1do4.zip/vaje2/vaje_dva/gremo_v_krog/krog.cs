﻿using System;

namespace gremo_v_krog
{
    class krog
    {
        static void Main(string[] args)
        {
            Console.Write("Vnesi elemente tabele: ");
            string elementi = Console.ReadLine();
            Console.WriteLine("Vnesi premik: ");
            int premik = int.Parse(Console.ReadLine()); // prebermo kar smo vnesli in spremenimo v tip int

            // ustvarimo tabele kamor bomo shranjevali
            string[] tabela, nova_tabela;

            KamPremaknemo(elementi, premik, out tabela, out nova_tabela);
            foreach (string stevilo in nova_tabela)
            {
                Console.Write(stevilo);
            };

        }
        /// <summary>
        /// Naredimo premik na tabeli
        /// </summary>
        /// <param name="elementi"> vnešen niz</param> 
        /// <param name="premik"> za koliko se niz zamakne</param>
        /// <param name="tabela"> tabela, v katere shranimo posamezen del elementa </param>
        /// <param name="nova_tabela"> v njej je zamaknjne niz</param>
        private static void KamPremaknemo(string elementi, int premik, out string[] tabela, out string[] nova_tabela)
        {
            tabela = elementi.Split(new char[] { ' ' }, StringSplitOptions.None); //razdelimo niz v podtabele z elementi niza
            int st_elementov = tabela.Length;
            nova_tabela = new string[st_elementov]; //naredimo novo tabelo v kateri bomo shranjevali premike

            for (int i = 0; i < st_elementov; i++)
            {
                int j = i - premik;
                while (j < 0)
                {
                    j += st_elementov;
                }
                while (j > st_elementov - 1)
                {
                    j -=  st_elementov;
                }
                nova_tabela[j] = tabela[i];
            }
        }
    }
}
