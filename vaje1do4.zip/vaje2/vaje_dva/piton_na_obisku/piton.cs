﻿using System;
using System.Linq;

namespace piton_na_obisku
{
    class piton
    {
        static void Main(string[] args)
        {
            Console.Write("Vnesi s: ");
            string s = Console.ReadLine();
            Console.Write("Vnesi t: ");
            string t = Console.ReadLine();
            Console.WriteLine(Beri(s, t));
        }
        /// <summary>
        /// Preverjam koliko znakov iz t se ponovi v s
        /// </summary>
        /// <param name="s"></param>
        /// <param name="t"></param>
        /// <returns></returns>
        public static string Beri(string s, string t)
        {
        
        int[] tabela_ponovitev = new int[t.Length]; //določim novo tabelo, ki ima enako veliko prostora kot naša tabela t
        for (int i = 0; i<t.Length; i++)
			{
                tabela_ponovitev[i] = s.Split(t[i]).Length - 1; // preštejm na koliko dellov mi razdeli glede na znakv nizu t
    
			}
        // m = max(c)
            int m = tabela_ponovitev.Max();
            string niz = "";

            //u = [t[i] for i in range(len(t)) if c[i] == m]
            for (int i = 0; i < t.Length; i++)
            {
                //c[i] == m
                if (tabela_ponovitev[i] == m)
                {
                    niz += t[i];
                }
            }
            if (niz.Length == 1)
                return ($"Črka, ki se največkrat ponovi je {niz}.");
            if (niz.Length == 2)
                return ($"Črki, ki se največkrat ponovita sta {niz}.");
            if (niz.Length == 0)
                return ($"Niz ne vsebuje črk iz niza t.");
            else
                return ($"Črke, ki se njavečkrat ponovijo so {niz}.");
        }
    }
}
