﻿using System;

namespace vaja_ena
{
    class Pek
    {
        static void Main(string[] args)
        {
            int steviloHlebcev, stevecNapacnih;
            BeriInPreverjaj(out steviloHlebcev, out stevecNapacnih);
            Odlocitev(steviloHlebcev, stevecNapacnih);
        }

        private static void BeriInPreverjaj(out int st_hlebcev, out int stevecNapacnih)
            //ko izluščamo kodo v metodo je opazil, da nas zanima koliko je napačnih in koliko je hlebcev
        {
            Console.Write("Vnesi predpisano tezo hlebca: ");
            double tezaPredpis = double.Parse(Console.ReadLine());
            Console.Write("Vnesi stevilo hlebcev v pekarni: ");
            st_hlebcev = int.Parse(Console.ReadLine());
            stevecNapacnih = 0;
            double minTeza = tezaPredpis * 0.8;
            double maxTeza = tezaPredpis * 1.2;
            for (int i = 1; i < st_hlebcev; i++)
            {
                Console.Write("Vnesi tezo: " + i + ". hlebca ");
                double dejanskaTeza = double.Parse(Console.ReadLine());
                //Če je teža hlebca 20% manjša od predpisa, ga štej med napačne hlebce
                if ((dejanskaTeza < minTeza) || (dejanskaTeza > maxTeza))
                    stevecNapacnih++;
            }
        }

        private static void Odlocitev(int steviloHlebcev, int stevecNapacnih)
        {
            //računamo ali bo pek pil vodo
            if (stevecNapacnih > steviloHlebcev * 0.15)
                Console.WriteLine("Peka v vodo takoj!!!!");
            else Console.WriteLine("Pek ima dobro mero");
        }

        
       
        
    }
}
