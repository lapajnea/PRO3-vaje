﻿using System;

namespace Predavanja
{
    class Euler { 
    static void Main(string[] args)
    {
        int l1 = 1;
        int l2 = 1;
        int current = l1 + l2;
        while (current.ToString().Length < 1000)
        {
            l2 = l1;
            l1 = current;
            current = l1 + l2;
        }
        Console.WriteLine(current);
    }
}

}
