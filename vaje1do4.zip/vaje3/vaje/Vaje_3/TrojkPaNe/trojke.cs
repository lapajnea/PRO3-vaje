﻿using System;
using System.Collections.Generic;
namespace TrojkPaNe

{
    class trojke
    {
        static void Main(string[] args)
        {

            Console.WriteLine("Napiši števila ločena s presledkom");
            string niz = Console.ReadLine();
            int st_stevil = niz.Split(' ').Length;
            int[] brez = new int[st_stevil];
            for (int i = 0; i < st_stevil; i++)
            {
                brez[i] = int.Parse(niz.Split(' ')[i]);
            }
            Console.WriteLine();
        }

        /// <summary>
        /// Iz vseh elementov v tabeli odstrani število 3
        /// </summary>
        /// <param name="t"></param>
        public static int[] Krajsaj(int[] t)
        {
            ///podatke zapišem kot tabelo nizov, 
            ///da bomo lažje preverjali vsak znak
            string[] tabela = new string[t.Length];
            for (int i = 0; i < t.Length; i++)
            {
                tabela[i] = t[i] + "";
            }

            string[] brez_trojk = new string[t.Length];
            for (int i = 0; i < tabela.Length; i++)
            {
                string stevilo = "";
                foreach (char znak in t)
                {
                    if (znak != '3')
                    {
                        stevilo += znak; ///shranim vse kar ni 3
                    }
                }
                if (stevilo != "") ///če je število sestavljeno iz samih trojk imamo prazen niz
                {
                    brez_trojk[i] = stevilo;
                }
            }
            return (brez_trojk);
        } 
    }

}
