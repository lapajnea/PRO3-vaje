﻿using System;

namespace Vaje_3
{
    class zamenjava_elementov
    {
        static void Main(string[] args)
        {
            int[] a = { 1, 2, 3,4,5,3,3}; 
            int[] b = Kopija(a);
            Console.WriteLine("Prej: "); 
            Izpisi("a", a); 
            Izpisi("b", b);
            a[1] = b[2];
            a[2] = b[1];
            Console.WriteLine("Potem: "); 
            Izpisi("a", a); 
            Izpisi("b", b);
        }
        static int[] Kopija(int[] t) { 
       
            return t;
                }
        static void Izpisi(string ime, int[] t) {
            Console.Write(ime + " ");
            foreach (int i in t)
            {
                Console.Write(i + " ");
            }
            Console.WriteLine();
        }
    }
}
