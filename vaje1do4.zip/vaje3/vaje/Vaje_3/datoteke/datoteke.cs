﻿using System;
using System.IO;

namespace datoteke
{
    class datoteke
    {
        static void Main(string[] args)
        {
            string pot = @"C:\Users\lapaj\OneDrive\Dokumenti\faks\3.pra\PROGRAMIRANJE_TRI\28.2.2022\vaje\Vaje_3\aaa.dat";
            ///StreamWriter pisanje = File.CreateText(pot);
            ///pisanje.WriteLine("To je moja datoteka");
            ///pisanje.Close();
            ////// to gor sem zakomentirala, ker semželela obdržati že napisane misli
            StreamReader branje = File.OpenText(pot);
            string vrstica = branje.ReadLine();
            branje.Close();

            Console.WriteLine(vrstica);
            StreamWriter dodajanje = File.AppendText(pot);
            string ime = Console.ReadLine();
            dodajanje.WriteLine(ime);
            dodajanje.Close();
            StreamReader novobranje = File.OpenText(pot);
            int i = 0;
            while ((vrstica = novobranje.ReadLine()) != null)
            {
                Console.WriteLine(++i + ": " + vrstica);
            }
            novobranje.Close();
        }
    }
}
