﻿using System;

namespace test
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] tabela1 = { 1, 2, 3, 4 };
            Console.WriteLine(tabela1);
        }
    }
}
