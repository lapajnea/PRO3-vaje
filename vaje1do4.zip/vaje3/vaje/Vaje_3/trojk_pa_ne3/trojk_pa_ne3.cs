﻿using System;

namespace trojk_pa_ne3
{
    class trojk_pa_ne3
    {
        static void Main(string[] args)
        {
            int[] tabela1 = new int[] { 5, 33, 5123 };

            Krajsaj_V1(ref tabela1);
            for (int i = 0; i < tabela1.Length; i++)
            {
                Console.Write(tabela1[i]+" ");
            }
            ///Console.WriteLine(string.Join(",", tabela1));
        }
        static void Krajsaj_V1(ref int[] t)
        {
            int[] brez_trojk = new int[t.Length];
            int kje_nova = 0;
            string niz_brez3 = "";
            for (int i = 0; i < t.Length; i++)
            {
                ///pretvorim število v niz
                string niz = t[i] + "";

                foreach (char elt in niz)
                {
                    ///znebim se trojk v nizu
                    if (elt != '3')
                    {
                        niz_brez3 += elt;
                    }
                }
            }
            if (niz_brez3 != "") ///če število ni bilo iz samih 3
            {
                ///pretvorimo v število
                int st_brez_trojk = int.Parse(niz_brez3);
                brez_trojk[kje_nova] = st_brez_trojk;
                kje_nova++;
            }

            int[] rezultat = new int[kje_nova];
            for (int i = 0; i < kje_nova; i++)
            {
                rezultat[i] = brez_trojk[i];
            }
            t = rezultat;
        }
    }
 }

