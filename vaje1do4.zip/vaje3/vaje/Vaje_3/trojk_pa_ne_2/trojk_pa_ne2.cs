﻿using System;

namespace trojk_pa_ne_2
{
    class trojk_pa_ne2
    {
        static void Main(string[] args)
        {
            int[] tabela1 = new int[] { 1, 2, 3, 4, 33, 34 };
            int[] tabela2 = new int[] { };
            ///int[] tabela3 = new int[] { 3, 333, 3333, 3323, 3, 0, -3 };
            
            Console.WriteLine("Brez trojk:" + string.Join(",", Krajsaj(tabela1)));
            Console.WriteLine("Brez trojk:" + string.Join(",", Krajsaj(tabela2)));
           /// Console.WriteLine("Brez trojk:" + string.Join(",", Krajsaj(tabela3)));
            Console.ReadLine();
            
        }
        public static int[] Krajsaj(int[] t)
        {
            int[] brez_trojk = new int[t.Length];
            int kje_nova = 0;
            string niz_brez3 = "";
            for (int i = 0; i < t.Length; i++)
            {
                ///pretvorim število v niz
                string niz = t[i] + "";
                
                foreach (char elt in niz)
                {
                    ///znebim se trojk v nizu
                    if (elt != '3')
                    {
                        niz_brez3 += elt;
                    }
                }
            }
            if (niz_brez3 != "") ///če število ni bilo iz samih 3
            {
                ///pretvorimo v število
                int st_brez_trojk = int.Parse(niz_brez3);
                brez_trojk[kje_nova] = st_brez_trojk;
                kje_nova++;
            }

            int[] rezultat = new int[kje_nova];
            for (int i = 0; i < kje_nova; i++)
            {
                rezultat[i] = brez_trojk[i];
            }
            return rezultat;
        }
    }

}
