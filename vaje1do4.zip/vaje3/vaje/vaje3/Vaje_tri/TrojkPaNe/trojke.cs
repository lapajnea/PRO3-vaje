﻿using System;
using System.Collections.Generic;
namespace TrojkPaNe

{
    class trojke
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Napiši števila, ločena s presledkom:");
            string stevila = Console.ReadLine();
            ///manjkajo mi testi

        }

        /// <summary>
        /// Iz vseh elementov v tabeli odstrani število 3
        /// </summary>
        /// <param name="t"></param>
        public static int[] Krajsaj(int[] t)
        {
            ///ustvarila bom novo tabelo v katero
            ///bom dala elemente brez 3
            int[] brez_tri = new int[t.Length];
            foreach (int st in t)
            {
                for (int i = 0; i < t.Length; i++)
                {
                    int novo_st = Odstrani(st);
                    brez_tri[i] = novo_st;

                }
            }


            return brez_tri;
        }

        /// <summary>
        /// odstranimo 3 iz števila
        /// </summary>
        /// <param name="stevilo"></param>
        public static int Odstrani(int stevilo)
        {
            string stt = stevilo.ToString();
            string brez = "";
            for (int i = 0; i < stt.Length; i++)
            {
                if (stt[i] != '3')
                {
                    brez += stt[i];
                }
            }
            return (int.Parse(brez));
        }
    }

}
