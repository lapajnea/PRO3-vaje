﻿using System;
using System.IO;

namespace dat_nakljucnih_stevil
{
    class nakljucna
    {
        static void Main(string[] args)
        {

        }
        /// <summary>
        /// Če ima poravnaj vrednost večjo od 0, 
        /// naj metoda izpisuje števila poravnano desno na poravnaj
        /// mest, sicer pa naj se obnaša kot prej.
        /// </summary>
        /// <param name="ime"></param>
        public static string Poravnaj(int stevilo, int poravnaj)
        {
            string stevka = "" + stevilo;
            if (poravnaj == 0)
            {
                return stevka;
            }
            return new string(' ', poravnaj - stevka.Length) + stevka;
        }
        /// <summary>
        /// ustvari datoteko naključnih števil. 
        /// V vsaki vrstici je lahko več števil, ki so med seboj 
        /// ločena s presledki. Metoda naj bo oblike
        /// </summary>
        /// <param name="ime"></param>
        /// <param name="maxvrstic"></param>
        /// <param name="maxstevil"></param>
        /// <param name="maxvrednost"></param>
        public static void Ustvari(string ime, int maxvrstic, int maxstevil, int maxvrednost)
        {
            StreamWriter pisi = File.CreateText(ime + ".txt"); ///nova datoteka
            Random nak_st = new Random(); ///naklkjučna števila

            for (int i = 0; i < maxvrstic; i++)
            {
                int st_stevil = nak_st.Next(maxvrednost);
                for (int j = 0; j < st_stevil; j++)
                {
                    pisi.Write(Poravnaj(nak_st.Next(maxvrednost), poravnaj));
                    if (j != st_stevil)
                    {
                        pisi.Write(' ');
                    }
                }
                pisi.WriteLine(' ');
            }
            pisi.Close();
        }


    }
}
