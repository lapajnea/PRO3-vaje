﻿using System;

namespace Lovljenje_napak
{
    class lovljenje_napak
    {
        static void Main(string[] args)
        {
            int[] test1 = tabeliraj(10);
            int[] test2 = tabeliraj(0);
            int[] test3 = tabeliraj(7); //liha števila
            int[] test4 = tabeliraj(54);
            for (int i = 0; i < 5; i++)
            {
                string preveri = "test"+i;
                string rezultat = string.Join(",", preveri);
                Console.WriteLine($"Metoda tabelira za test{i} vrne:");
                foreach(int elt in preveri)
                {
                    Console.Write(elt + " ");
                    
                }
                Console.WriteLine();

                
            }
          

        }
        public static int f(int i)
        {
            return (100 / (i % 3));
        }
        /// <summary>
        /// metoda vrne tabelo vrednosti neke funkcije f na intervalu [0, n] 
        /// kjer je vrednost celo število, če njena vrednst ni celo število
        /// vrne 0
        /// </summary>
        /// <param name="n"> velikost tabele</param>
        /// <returns></returns>
        public static int[] tabeliraj(int n)
        {
            int[] tabela = new int[n]; /// v tabelo bomo shranjevali rezultate
            for (int i = 0; i < n; i++)
            {
                try
                {
                    tabela[i] = f(i); ///poiskusimo izračunati
                }
                catch
                {
                   tabela[i] = 0; /// to se izvede, če ne moremo poračunati
                }
            }
            return tabela;
        }
    }
}
