﻿using System;

namespace Lovljenje_napak2
{
    class lovljenje_napak2
    {

        static void Main(string[] args)
        {
            ///Console.WriteLine(PreberiInt("Vnesi število: "));
            /// Console.WriteLine(preberiIntMeje("Vnesi celo število med 10 in 40: ", 10, 40));
            /// Console.WriteLine(preberiIntMeje2("Vnesi celo število med -100 in 100: "));
            ///Console.WriteLine(preberiIntMeje2("Vnesi celo število med 1 in 100: ", 1));
            ///Console.WriteLine(preberiIntMeje2("Vnesi celo število ", zgornja_meja = 5));
            ///Console.WriteLine(preberiIntMeje2("Vnesi celo število", 1, 5));
            Console.WriteLine(vnosTabele());
        }
        
        /// <summary>
        /// metoda povpraša po številu in preveri ali je število celo število
        /// </summary>
        /// <param name="sporocilo"></param>
        /// <returns></returns>
        public static int PreberiInt(string sporocilo)
        {
            Console.Write(sporocilo);
            string vnos = Console.ReadLine();
            try
            {
                int stevilo = int.Parse(vnos);
                return stevilo;
            }
            catch (FormatException)
            {
                Console.WriteLine($"NAPAKA: {vnos} ni celo stevilo!");
                return PreberiInt(sporocilo); ///povpraša ponovno
            }
        }
        /// <summary>
        /// funkcija bo preverila ali je vpisano število celo število ( s pomočjo
        /// prejšne funkcije) ter da je število v mejah
        /// </summary>
        /// <param name="besedilo"></param>
        /// <param name="spodnja_meja"></param>
        /// <param name="zgornja_meja"></param>
        /// <returns></returns>
        public static int preberiIntMeje(string sporocilo, int spodnja_meja, int zgornja_meja)
        {
            int stevilo = PreberiInt(sporocilo);
            if (spodnja_meja <= stevilo && zgornja_meja >= stevilo)
            {
                return stevilo;
            }
            else
            {
                Console.WriteLine($"NAPAKA: {stevilo} ni med {spodnja_meja} in {zgornja_meja}");
                return preberiIntMeje(sporocilo, spodnja_meja, zgornja_meja);
            }

        }
        /// <summary>
        /// funkcija preveri ali je število med -100 in 100
        /// </summary>
        /// <param name="sporocilo"></param>
        /// <param name="spodnja_meja"></param>
        /// <param name="zgornja_meja"></param>
        /// <returns></returns>
        public static int preberiIntMeje2(string sporocilo, int spodnja_meja = -100, int zgornja_meja = 100)
        {

            return preberiIntMeje(sporocilo, spodnja_meja, zgornja_meja);
        }
       
         /// <summary>
         /// Funkcija zahteva vnost nenegativnega celega števila za dolžino tabele,
         /// nato pa še toliko celih števil
         /// </summary>
         /// <param name="n"></param>
         /// <returns></returns>
         public static int[] vnosTabele()
        {
            int st_elementov = preberiIntMeje("Vnesi število elementov: ", 0, 20); ///recimo, da ne želimo večje tavele
            int[] tabela = new int[st_elementov];
            for (int i = 0; i < st_elementov; i++)
            {
                Console.WriteLine(PreberiInt($"Vnesi {i+1}. element: "));
                int st = int.Parse(Console.ReadLine());
                tabela[i] = st;

            }
            return tabela;

        }
    }
   
        
    }
    

