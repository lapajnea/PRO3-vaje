﻿using System;

namespace bisekcija
{
    class bisekcija
    {
        static void Main(string[] args)
        {
            int[] test = new int[] { 1,2,3,4,5,6,7,8,9};
            Console.WriteLine(Biskekcija(test, 3));
        } 
        /// <summary>
        /// Funkcija generira bisekcijo, ki poišče elelement in ga vrne. 
        /// Vrne tudi mesto, kjer se nahaja.
        /// Če elementa nimamo vrnemo -1
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="tabela"></param>
        /// <param name="iskan"></param>
        /// <returns></returns>
        public static int Biskekcija<T>(T[] tabela, T iskan) where T: IComparable  
        {
            int minimum = 0;
            int maksimum = tabela.Length;

            while (minimum < maksimum)
            {
                int sredisce = (minimum + maksimum) / 2;
                if (tabela[sredisce].CompareTo(iskan) == 0) return sredisce;
                else if (tabela[sredisce].CompareTo(iskan) < 0) minimum = ++sredisce;
                else maksimum = --sredisce;
            }
            return -1;
        }

    }
}
