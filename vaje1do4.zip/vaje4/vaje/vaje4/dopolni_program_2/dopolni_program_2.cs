﻿using System;

namespace dopolni_program_2
{
    class dopolni_program_2
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Program izpiše vrednost izraza (a+b)/c, za cela števila a,b,c");
            int a = PreveriStevilo("Vnesi a: ");
            int b = PreveriStevilo("Vmesi b: ");

            /// za c mormamo preveriti, da je različen od 0    
            while (true) {
                int c = PreveriStevilo("Vnesi c: ");
                try
                {
                    Console.WriteLine("(a+b)/c = " + ((a + b) / c));
                }
                catch (DivideByZeroException)
                {
                    Console.WriteLine("Delneje z 0 ni mogoče.");
                }
                catch (Exception e)
                {
                    Console.WriteLine("Nekaj je šlo narobe.");
                    Console.WriteLine(e.ToString());
                    break;
                } }

        }
       
        
        /// <summary>
        /// Metoda povpraša po številu in preveri ali je to število celo število
        /// Sprašuje dokler ni vnešeno celo število
        /// </summary>
        /// <param name="besedilo">vnesemo število kot niz</param>
        /// <returns></returns>
        public static int PreveriStevilo(string besedilo)
        {
            Console.Write(besedilo); ///izpišemo besedilo
            
            try
            {
                int st = int.Parse(Console.ReadLine()); /// prebermo vnesšeno število
                return st;
            }
            catch
            {
                Console.WriteLine("Vpisati moraš celo števolo!");
                return PreveriStevilo(besedilo);
            }
        }
    }
}
