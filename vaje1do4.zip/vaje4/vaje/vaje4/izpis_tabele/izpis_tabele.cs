﻿using System;

namespace izpis_tabele
{
    class izpis_tabele
    {
        static void Main(string[] args)
        {
            int[] test = new int[] { 12, 5, 6, 78, 3, 5, 6, 21, 434, 56, 42, 7 };
            ///char[] test1 = new char[] {'Andreja', 'Klavdija', 'Amadej', 'Hana', 'Tit', 'Benisa' };
            IzpisTabele(test, 2, ":");
           /// IzpisTabele(test1, 3, "-");
        }
        /// <summary>
        /// Iz tabele izpiše tabelo, in bo izpisovala po n elementov tabele v vrsto
        /// Elemente v vrsti loči z nizom vmes
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="tab"></param>
        /// <param name="n"></param>
        /// <param name="vmes"></param>
        public static void IzpisTabele<T>(T[] tab, int n, string vmes)
        {
            if (n != 0) /// če je enak nič samo izpišemo tabelo
            {
                for (int i = 0; i < tab.Length; i++)
                {
                    if (i % n == 0) 
                    {
                        if ( i != 0)
                        {
                            Console.WriteLine();
                        }
                    }
                    else /// izpisali smo zadostno število elementov tabele
                    {
                        Console.Write(vmes);
                    }
                    Console.Write(tab[i]); ///izpišemo znak, ki sledi
                }
            }
            Console.WriteLine();
        }
    }
}
