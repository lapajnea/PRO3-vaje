﻿using System;

namespace minmax1
{
    class minmax
    {
        static void Main(string[] args)
        {

            int[] test = new int[] { 1, 2, 3, 4, 5, 3, 2, 6, 8, 7, 87, 4, 3, 2, 7 };
            int[] resitev = MinMax(test);
            Console.WriteLine($"min: {resitev[0]} max: {resitev[1]}");
            string[] test2= new string[] { "Andreja", "Klavdija", "Amadej", "Peter", "Hana", "Ana"};
            string[] resitev2 = MinMax(test2);
            Console.WriteLine($"min: {resitev2[0]} max: {resitev2[1]}");
        }

        /// <summary>
        /// funkcija vrne tabelo iz dveh elementov
        /// prvi je najmanjsi v tabeli, drugi je največji
        /// </summary>
        /// <param name="tabela"></param>
        /// <returns></returns>
        public static int[] MinMax(int[] tabela)
        {
            int[] rezultat = new int[2] { tabela[0], tabela[0] };
            foreach (int elt in tabela)
            {
                if (elt > rezultat[1]) rezultat[1] = elt;
                if (elt < rezultat[0]) rezultat[0] = elt;

            }
            return rezultat;
        }
       public static string[] MinMax(string[] tabela)
        {
            string[] rezultat = new string[2] { tabela[0], tabela[0] };
            foreach (string elt in tabela)
            {
                if (elt.Length > rezultat[1].Length) rezultat[1] = elt;
                if (elt.Length < rezultat[0].Length) rezultat[0] = elt;
            }
            return rezultat;
        }
    }
}
