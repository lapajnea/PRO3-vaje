﻿using System;

namespace prozenje_izjem
{
    class prozenje_izjem
    {
        static void Main(string[] args)
        {
            
            Console.WriteLine(racunanje(3));
        }
        /// <summary>
        /// metoda povpraša po številu in preveri ali je število celo število
        /// </summary>
        /// <param name="sporocilo"></param>
        /// <returns></returns>
        public static int PreberiInt(string sporocilo)
        {
            Console.Write(sporocilo);
            string vnos = Console.ReadLine();
            try
            {
                int stevilo = int.Parse(vnos);
                return stevilo;
            }
            catch (FormatException)
            {
                Console.WriteLine($"NAPAKA: {vnos} ni celo stevilo!");
                return PreberiInt(sporocilo); ///povpraša ponovno
            }
        }
        /// <summary>
        /// funkcija bo preverila ali je vpisano število celo število ( s pomočjo
        /// prejšne funkcije) ter da je število v mejah
        /// </summary>
        /// <param name="besedilo"></param>
        /// <param name="spodnja_meja"></param>
        /// <param name="zgornja_meja"></param>
        /// <returns></returns>
        public static int preberiIntMeje(string sporocilo, int spodnja_meja, int zgornja_meja)
        {
            int stevilo = PreberiInt(sporocilo);
            if (spodnja_meja <= stevilo && zgornja_meja >= stevilo)
            {
                return stevilo;
            }
            else
            {
                Console.WriteLine($"NAPAKA: {stevilo} ni med {spodnja_meja} in {zgornja_meja}");
                return preberiIntMeje(sporocilo, spodnja_meja, zgornja_meja);
            }

        }

        public static void racunanje(int n)
        {
            string[] racunaj = racun();
            Console.WriteLine(racun());
            int pravi_rezultat = poracunaj(racunaj[0], racunaj[2], racunaj[1]); ///tu mi poračuna pravi rezultat
            for (int i = 0; i < n; i++)
            {
                int resitev = PreberiInt(string.Join(" ", racunaj));
                try
                {
                    if (pravi_rezultat == resitev) break;

                }
                catch (FormatException)
                {
                    Console.WriteLine($"NAPAKA: {resitev} ni celo število.");
                    continue;

                }
        }
        }
        /// <summary>
        /// zgenerira naključen račun
        /// </summary>
        /// <returns></returns>
        public static string[] racun()
        {
            string[] izraz = new string[4];
            string[] operacije = new string[] {"+", "-", "*"};
            Random rnd = new Random();
            int a = preberiIntMeje("", 0, 100);
            int b = preberiIntMeje("", 0, 100);
            int indeks = rnd.Next(operacije.Length);
            string operacija = operacije[indeks];
            izraz[0] = a + ""; 
            izraz[1] = operacija;
            izraz[2] = b + "";
            izraz[3] = "=";

            return izraz;
        }
        /// <summary>
        /// izračuna izraz
        /// </summary>
        /// <param name="a"></param>
        /// <param name="b"></param>
        /// <param name="operacija"></param>
        /// <returns></returns>
        public static int poracunaj(string a, string b, string operacija)
        {
            if (operacija == "+") return int.Parse(a) + int.Parse(b);
            if (operacija == "-") return int.Parse(a) - int.Parse(b);
            else return int.Parse(a) * int.Parse(b);
        }

    }

}
