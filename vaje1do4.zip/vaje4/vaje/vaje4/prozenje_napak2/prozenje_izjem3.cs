﻿using System;

namespace prozenje_napak2
{
    class prozenje_izjem3
    {
        static void Main(string[] args)
        {
           /// double[] test = NicleKvEnacbe(0, 2, 0);
            
            double[] test1 = NicleKvEnacbe(1, 1, 1);
            Console.WriteLine($"x1 = {test1[0]}, x2 = {test1[1]}");
            double[] test2 = NicleKvEnacbe(0, 2, 3);
            double[] test4 = NicleKvEnacbe(2, -3, -2);
           
            
        }

        public static double[] NicleKvEnacbe(double a, double b, double c)
        {
            if (a == 0)
            {
                throw new Exception("Nimamo rešitve za kvadratno enačbo!");
            }

            double D = Math.Pow(b, 2) - 4 * a * c;
            if (D < 0)
            {
                throw new Exception("Funkcija vsebuje kompleksne niče.");

            }
            if (a < 0 && b < 0 && c < 0)
            {
                throw new Exception("Nimamo rešitve");
            }

            double[] rezultat = new double[] { (-b + Math.Sqrt(D)) / (2 * a), (-b - Math.Sqrt(D)) / (2 * a) };
            return rezultat;

        }
    }
}
