﻿using System;

namespace snippet
{
    class Program
    {
        static void Main(string[] args)
        {

            int stevilo = int.Parse(Console.ReadLine());
        }
    }
}
