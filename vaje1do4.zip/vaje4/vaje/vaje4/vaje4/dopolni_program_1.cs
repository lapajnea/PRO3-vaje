﻿using System;

namespace vaje4
{
    class dopolni_program_1
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Program izpiše vrednost izraza (a+b)/c, za cela števila a,b,c");
            try
            {
                Console.Write("Vnesi a: ");
                int a = int.Parse(Console.ReadLine());
                Console.Write("Vnesi b: ");
                int b = int.Parse(Console.ReadLine());
                Console.Write("Vnesi c: ");
                int c = int.Parse(Console.ReadLine());
                Console.WriteLine("(a+b)/c = " + ((a + b) / c));
            }

            catch (DivideByZeroException e)
            {
                Console.WriteLine("Deljenje z 0 ni mogoče.");
                Console.WriteLine(e.ToString());
            }
            catch (FormatException e)
            {
                Console.WriteLine("Za računanje je potrebno vnesti števila!");
                Console.WriteLine(e.ToString());
            }
            catch (Exception e)   /// v primeru kakšne druge napake
            {
                Console.WriteLine("Nekje je še vedno napaka!");
                Console.WriteLine(e.ToString());
            }
        }
    }
}
