﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;


namespace Datoteka_1
{
    public class obracamo
    {
        static void Main(string[] args)
        {
            string pot = @"C:..\..\..\test_vhod.dat";
            StreamWriter pisi = File.CreateText(pot);
            pisi.WriteLine("Peter  -spet zamuja.");
            pisi.WriteLine(" -Lep    dan");
            pisi.WriteLine("Konec");
            pisi.Close();

            Obrni("test_vhod", "test_izhod");

        }
        /// <summary>
        /// datoteko vhod prepiše na datoteko izhod, tako da:
        /// vsako besedo, ki se začne z - zapiše v obratnem vrstnem redu,
        /// odstrani odvečne presledke
        /// če vhodne datoteke ni, na izhodno datoteko napiše 42 vrstic 
        /// z besedilom 
        /// </summary>
        /// <param name="imeVhod"></param>
        /// <param name="imeIzhod"></param>
        public static void Obrni(string imeVhod, string imeIzhod)
        {
            string pot = @"C:\Users\lapaj\OneDrive\Dokumenti\faks\3.pra\PROGRAMIRANJE_TRI\vaje5\vaje5\Datoteka_1\";
            ///če vhodna datoteka ne obstaja 
            if (!File.Exists(pot + imeVhod + ".dat") )
            {
                StreamWriter dat = File.CreateText(pot + imeVhod+".dat");
                for (int i = 0; i < 42; i++)
                {
                    dat.WriteLine("Tudi pri težjih problemih smo že odpovedali!");
                }
                dat.Close();
            }
            /// če vhodna datoteka obstaja
            else
            {
                StreamReader vr = File.OpenText(pot + imeVhod+".dat"); ///odprem za branje
                string vrstica = vr.ReadLine();
                while (vrstica != null)
                {

                    ///string[] besedilo = vrstica.Split(" ");
                    ///string[] novo = new string[besedilo.Length]; ///shranjujem obrnjeno
                    List<string> novo = new List<string>();
                    List<string> tekst = new List<string>(vrstica.Split(' '));
                    foreach (string beseda in tekst)
                    {
                       /// if (beseda[0] == '-')
                        ///{
                          ///  novo.Add(" " + obrnjeno(beseda.Substring(1)));
                        ///}
                    if (beseda == " ") { continue; } ///preseledkov ne prepišemo, vedno jih le dodamo med besedo
                     else
                        {
                            novo.Add(" " + beseda);
                        }
                        /// pišemo na datoteko
                        StreamWriter pisi = File.CreateText(pot + imeIzhod);
                        for (int i = 0; i < novo[i].Length; i++) ///vrstica.Split(' ').Length
                        {
                            pisi.Write(novo[i]);
                            pisi.Close();
                        }

                        vrstica = vr.ReadLine();
                    }

                    


                    vrstica = vr.ReadLine();
                }
            }

        }

        /// <summary>
        /// funkcija obrne niz, ki je oblike '-niz'
        /// vrne pa ' zin'
        /// torej...dolzina vhodnega in izhodnega niza sta enaki
        /// </summary>
        /// <param name="niz"></param>
        /// <returns></returns>
        public static string obrnjeno(string niz)
        {
            char[] znaki = niz.ToCharArray();
            Array.Reverse(znaki);
            return new string(znaki);
        }
    }
}