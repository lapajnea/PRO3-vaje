﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace datoteke
{
     public class mnozimo_se
    {
        static void Main(string[] args)
        {
            string pot = @"C:\Users\lapaj\OneDrive\Dokumenti\faks\3.pra\PROGRAMIRANJE_TRI\vaje5\vaje5\datoteka\Test1.dat";

            //StreamWriter test1 = File.CreateText(pot);
            //for (int i = 0; i < 5; i++)
            //{
            //    string napisi = Console.ReadLine();
            //    test1.WriteLine(napisi);
            //}
            //test1.Close();
            ///var test = racunaj(pot);
            Console.WriteLine(racunaj(@"C:\Users\lapaj\OneDrive\Dokumenti\faks\3.pra\PROGRAMIRANJE_TRI\vaje5\vaje5\datoteka\Test1.dat"));
        }

        /// <summary>
        /// funkcija prebere števila iz datoteke, ki so zapisana
        /// vsaka v svoji vrstici in jihz zmnoži med sabo
        /// </summary>
        /// <param name="datoteka"></param>
        /// <returns></returns>
        public static string racunaj(string datoteka)
        {
            int stevec = 1;
            int imenovalec = 1;
            StreamReader dat = File.OpenText(datoteka);
            string vrstica = dat.ReadLine();
            while (vrstica != null)
            {
                //try
                //{
                //    int stevilo = int.Parse(vrstica); //imamo celo število, lahko pomnožimo
                //    stevec = stevec * stevilo;
                //}
                //catch
                //{
                //    var ulomek = vrstica.Split('/');
                //    stevec = stevec * int.Parse(ulomek[0]);
                //    imenovalec = imenovalec * int.Parse(ulomek[1]);
                //}
                var stevilo = vrstica.Split('/');
                if (stevilo.Length == 1) stevec = stevec * int.Parse(stevilo[0]);
                else
                {
                    stevec = stevec * int.Parse(stevilo[0]);
                    imenovalec = imenovalec * int.Parse(stevilo[1]);
                }

                vrstica = dat.ReadLine();
            }
            dat.Close();
            string rezultat = stevec + "/" + imenovalec;

            return (rezultat);


        }
    }
}

