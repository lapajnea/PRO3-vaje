﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace genericni_tipi1
{
    public class kolikoNajvecjih
    {
        static void Main(string[] args)
        {
            int[] test = new int[] {1 };
            Console.WriteLine(koliko_najvecjih(test));

            int[] test1 = new int[] { 1,1,1};
            Console.WriteLine(koliko_najvecjih(test1));

            int[] test2 = new int[] { -1,3,4};
            Console.WriteLine(koliko_najvecjih(test2));
        }

        /// <summary>
        /// funkcja vrne število elementov tabele,
        /// ki so enaki največjemu elemenetu v tabli
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="tabela"></param>
        public static int koliko_najvecjih<T>(T[] tabela) where T : IComparable<T>
        {
            if (tabela.Length == 0)
            {
                throw new Exception("prazna tabela");
            }
            T element = tabela[0];
            ///poiščemo največji element
            for (int i = 0; i < tabela.Length; i++)
            {
                if (tabela[i].CompareTo(element) > 0) element = tabela[i];
            }

            int st = 0;
            ///preštejemo št elementov z največjo vrednost
            foreach (T elt in tabela)
            {
                if (elt.CompareTo(element) == 0) st++;
            }
            



            return st;

        }
    }
}
