﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KvadratnaEnacba
{
    public class kvadratna_enacba
    {
        static void Main(string[] args)
        {
            ///test
            ///Console.WriteLine(ničleKvEnačbe(0, 0, 0));
            //Console.WriteLine(ničleKvEnačbe(1, 1, 1));
            Console.WriteLine(ničleKvEnačbe(-3, 3, 0)[0]);
            //Console.WriteLine(ničleKvEnačbe(1.5, 7, -3.2));

            //Console.Write("a: ");
            //double a = double.Parse(Console.ReadLine());
            //Console.Write("b: ");
            //double b = double.Parse(Console.ReadLine());
            //Console.Write("c: ");
            //double c = double.Parse(Console.ReadLine());
            //Console.WriteLine(string.Join(" ", ničleKvEnačbe(a, b, c)));
        }
        /// <summary>
        /// funkcija vrne ničle kvadratne enačbe kot tabelo dveh
        /// elementiv
        /// oblika enačbe ax^2 + bx + c = 0
        /// oblika rešitev = (-b +- sqrt(b^2 - ac))/2a
        /// </summary>
        /// <param name="a"></param>
        /// <param name="b"></param>
        /// <param name="c"></param>
        /// <returns></returns>
        public static double[] ničleKvEnačbe(double a, double b, double c)
        {
            double[] tabela = new double[2];
            double d = Math.Pow(b, 2) - 4 * a * c;
            if (d < 0)
            {
                throw new Exception("Imamo kompleksne rešitve");
            }
            if (a == 0)
            {
                throw new Exception("Enačba ni kvadratna ");
            }
            ///poračunamo ničle

            double x1 = (-b + Math.Sqrt(d)) / (2 * a);
            double x2 = (-b - Math.Sqrt(d)) / (2 * a);
            tabela[0] = x1;
            tabela[1] = x2;
            return tabela;


        }
    }
}

