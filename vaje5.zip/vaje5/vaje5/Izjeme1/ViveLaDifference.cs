﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Izjeme1
{
    class ViveLaDifference
    {
        static void Main(string[] args)
        {
            Console.WriteLine(VDL());

        }

        public static double VDL()
        {

            Console.WriteLine("Zmanjševanec: ");
            double zmanjsevalec = double.Parse(Console.ReadLine());
            Console.WriteLine(" Odštevanec: ");
            double odstevanec = double.Parse(Console.ReadLine());
            double resitev = zmanjsevalec - odstevanec;

            if (zmanjsevalec < odstevanec)
            {
                throw new Exception("Odštevanec mora biti manjši od zmanjševanca!");
            }

            if (zmanjsevalec < 0)
            {
                throw new Exception("Zmanjševalec mora biti manjši od zmanjševalca!)");

            }
            ///TODO še preveri ali je tipa int


            
            else
            {
                
                return (resitev);
            }
            return resitev;
        }
    }
}
