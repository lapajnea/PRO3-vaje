﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Osnove2
{
    public class zoprna_sedmica
    {
        static void Main(string[] args)
        {
            int[] test = new int[] { 1, 7, 14, 7, 15, 2, 6};

            int[] rezultat = PoisciVII(ref test);
            for (int i = 0; i < rezultat.Length; i++)
            {
                Console.Write(rezultat[i] + " "); 

            }
            foreach (int elt in test)
            {

                Console.WriteLine(elt);
            }

        }
        /// <summary>
        /// Funkcija vrne tabelo z dvema elementoma.
        /// Prvi je število elementov, ki so delijva z 7, 
        /// drugi element pa je vsota preostalih števil
        /// </summary>
        /// <param name="tabela"></param>
        /// <returns></returns>
        public static int[] PoisciVII(ref int[] tabela)
        {
            int[] rezultat = new int[2];
            int koliko7 = 0;
            int vsota = 0;
            int koliko_ostalih = 0;
            foreach (int st in tabela)
            {

                if (st % 7 == 0)
                {
                    koliko7++;
                }
                else
                {
                    vsota += st;
                    koliko_ostalih++;
                }


            }
            rezultat[0] = koliko7;
            rezultat[1] = vsota;

            int[] tabela_brez7 = new int[koliko_ostalih];

            int kje = 0;
            for (int i = 0; i < tabela.Length; i++)
            {
                if (tabela[i] % 7 != 0)
                {
                    tabela_brez7[kje] = tabela[i];
                }
                kje++;
            }

            tabela = tabela_brez7;
            return rezultat;
        }
    }
}