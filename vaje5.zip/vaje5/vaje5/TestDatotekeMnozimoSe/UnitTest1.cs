﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using datoteke;
using System.IO;
namespace TestDatotekeMnozimoSe
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {
            string pot = @"C:\Users\lapaj\OneDrive\Dokumenti\faks\3.pra\PROGRAMIRANJE_TRI\vaje5\vaje5\Datoteke\Test1.dat";

            StreamWriter test1 = File.CreateText(pot);
            for (int i = 0; i < 5; i++)
            {
                string napisi = Console.ReadLine();
                test1.WriteLine(napisi);
            }
            test1.Close();
            var test = mnozimo_se.racunaj(pot);


            Assert.AreEqual(0, mnozimo_se.racunaj(@"C:\Users\lapaj\OneDrive\Dokumenti\faks\3.pra\PROGRAMIRANJE_TRI\vaje5\vaje5\Datoteke\Test1.dat"));

        }
    }
}
