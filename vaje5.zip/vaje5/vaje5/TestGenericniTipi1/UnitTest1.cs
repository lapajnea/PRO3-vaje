﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using genericni_tipi1;

namespace TestGenericniTipi1
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {
            int[] test = new int[] { 1, 2, 2, 3, 4, 5, 4, 3, 5 };
            Assert.AreEqual(2, kolikoNajvecjih.koliko_najvecjih(test));  
        }
        [TestMethod]
        public void TestMethod2()
        {
            int[] test = new int[] { 0,0,0,0,0 };
            Assert.AreEqual(5, kolikoNajvecjih.koliko_najvecjih(test));
        }
        [TestMethod]
        public void TestMethod3()
        {
            int[] test = new int[] {};
            Assert.AreEqual("System.Exception: prazna tabela", kolikoNajvecjih.koliko_najvecjih(test));
        }
    }
}
