﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using Osnove2;


namespace TestZoprnaSedmica
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {
            int[] test = new int[] { 1, 7, 14, 7, 2 };
            
            int[] rezultat = zoprna_sedmica.PoisciVII(ref test);

            Assert.AreEqual(rezultat, zoprna_sedmica.PoisciVII(ref test));
           
        }
    }
}
