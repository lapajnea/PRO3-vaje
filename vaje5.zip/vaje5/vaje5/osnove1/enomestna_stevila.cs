﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace osnove1
{
    public class enomestna_stevila
    {
        static void Main(string[] args)
        {
            Console.WriteLine(EnomestnaStevila("a1b2c3d9"));
            Console.WriteLine(EnomestnaStevila("12. 3. 2020"));
            Console.WriteLine(EnomestnaStevila("D12"));
           
        }

        public static int EnomestnaStevila(string sporocilo)
        {
            int koliko = 0;
            
            List<char> stevila = (new char[] { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9' }).ToList();
            
            

            for (int i = 1; i < sporocilo.Length-1; i++)
            {
                if (!stevila.Contains(sporocilo[i- 1]) && stevila.Contains(sporocilo[i]) && !stevila.Contains(sporocilo[i + 1])) ///preverim vse, razen zadnjega
                {
                    koliko++;
                }
                
            }

            ///preverimo še zadnja dva elementa niza
            string zadnja = (sporocilo.Substring(sporocilo.Length - 2, 2));
            if (!stevila.Contains(zadnja[0]) && stevila.Contains(zadnja[1])) { koliko++; }
            return koliko;
            
        }
    }
}
