﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kosara
{
    public class Kosarica<T>
    {
        private T _objekt;
        
        /// <summary>
        /// konstruktor
        /// </summary>
        /// <param name="objekt"></param>
        public Kosarica(T objekt)
        {
            this.objekt = objekt;
        }

        public T objekt
        { get { return this._objekt; } 
            set { this._objekt = value; } 
        }

        public override string ToString()
        {
            return this.objekt.ToString();
        }

            
    }
}
