﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Registracija
{
    public class Registracijaa
    {
        static void Main(string[] args)
        {

            // Registracijaa test = new Registracijaa("LJ 542AB");
            //  Console.WriteLine(test.obmocje); //get metoda
            // test.obmocje = "neki"; //Set metoda in value == "neki"

            // zgeneriramo naklkjučnih 100 registracij

            Random rnd = new Random();
            string[] tabela_registracij = new string[100];
            string ustrezni_znaki = "ABCDEFGHIJKLMNOPRSTUVZ0123456789";

            string registracija = "";
            for (int i = 0; i < 100; i++)
            {
                int st_obmocji = Registracijaa.obmocja.Length;
                registracija+=(Registracijaa.obmocja[rnd.Next(st_obmocji)]);

                //dodati moramo še 5 drugih znakov

                ///for (int j = 0; j < 5; j++)
               /// {
               ///     registracija += ustrezni_znaki[rnd.Next(ustrezni_znaki.Length)];
              ///  }
                tabela_registracij.Append(registracija);
               //Console.WriteLine(tabela_registracij[10]);

            }
            string[] test = { "ojojj", "hehe", "hojho"};
            foreach(var primer in tabela_registracij)
            {
                Console.WriteLine(primer);
            }
        }
        
        private string regija;// registrska sestavljena tabele, v prvi tabeli je območje v drugi ostal del
        private string znaki;
        private static string[] obmocja = new string[] { "LJ", "KR", "KK", "MB", "MS", "KP", "GO", "CE", "SG", "NM", "PO" };
        public Registracijaa(string registrska)
        {
            this.regija = registrska.Split(' ')[0];
            this.znaki = registrska.Split(' ')[1];  
            
        }

        /// <summary>
        /// izpiše registrsko številko
        /// </summary>
        /// <returns></returns>
        public override string ToString()
        {
            return ($"Registrska št: {this.regija}  {this.znaki}.");
        }

        /// <summary>
        /// preverimo ali je pravilno podano obmocje
        /// </summary>
        public string obmocje
        {
            get { return this.regija; }
            set
            {
                if (!obmocja.Contains(this.regija))
                {
                    throw new Exception("Regija ni veljavno!");
                }
                if (this.regija.Length !=2)
                {
                    throw new Exception("Regija je sestavljena iz dveh črk!");
                }
                if (!char.IsLetter(this.regija[0]) && !char.IsLetter(this.regija[1]))
                {
                    throw new Exception("Regija je sestavljena iz črk!");
                }
                this.regija = value;
            }
                
        }
        /// <summary>
        /// preverimo ali je pravilno podana registracija
        /// </summary>
        public string registracija
        {
            get { return this.znaki; }
            set
            {
                if (this.znaki.Length!=5)
                {
                    throw new Exception("Drugi del registerske mora biti sestavljen iz petih znakov!");
                }
                foreach (char znak in this.znaki)
                {
                    if (!char.IsLetterOrDigit(znak))
                    {
                        throw new Exception(" Registracija vsebuje le črke in številke!");
                    }
                }
                this.znaki = value;
            }
        }

        /// <summary>
        /// dodamo novo območje
        /// </summary>
        /// <param name="nova_regija"></param>
        public void DodajRegijo( ref string[] nova_regija)
        {

            foreach (string obmocje in nova_regija)
            {
                if (!obmocja.Contains(obmocje))
                {
                    Registracijaa.obmocja.Append(obmocje);
                }
                
            }
            

        }

       /// <summary>
       /// odstranimo območja
       /// </summary>
       /// <param name="regija"></param>
       public void OdstraniRegijo(string regija)
        {
            string[] tabela = new string[obmocja.Length - 1];
            if (!obmocja.Contains(regija))
            {
                throw new Exception("Tega območja sploh nimamo");
            }
            else
            {
                for (int i = 0; i < obmocja.Length - 1; i++)
                {
                    if (obmocja[i] != regija)
                    {
                        tabela.Append(obmocja[i]);
                    }
                }
            }
            Registracijaa.obmocja = tabela;
        }


      /// <summary>
      /// izpiše koliko je registriranih vozil v dani regiji
      /// </summary>
      /// <param name="registerske"></param>
      /// <returns></returns>
      public Dictionary<string, int> StRegij(Registracijaa[] registerske)
        {
            Dictionary<string, int> pogostosti = new Dictionary<string, int>();


           foreach (string re in Registracijaa.obmocja)//za ključ damo regije
            {
                pogostosti.Add(re, 0);
            }
            foreach (Registracijaa elt in registerske)
            {
                pogostosti[elt.obmocje]++;
            }
            return pogostosti;
                }

       
    }
}
