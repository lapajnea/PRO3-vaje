﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RegistracijaNova
{
    public class Registracija
    {
        static void Main(string[] args)
        {
            // RANDOM GENERATOR

            Random rng = new Random();
            Registracija[] tabelaReg = new Registracija[100];
            string znaki = "ABCDEFGHIJKLMNOPRSTUVZ0123456789";
            string[] nakljucnaObmocja = new string[100];
            for (int i = 0; i < 100; i++)
            {
                int x = rng.Next(spisek_obmocij.Count);
                nakljucnaObmocja[i] = spisek_obmocij[x];
            }
            string[] nakljucneReg = new string[100];
            string regg = "";
            for (int i = 0; i < 100; i++)
            {
                for (int j = 0; j < 5; j++)
                {
                    int x = rng.Next(znaki.Length);
                   
                    regg = regg + znaki[x];
                   
                }
                
                nakljucneReg[i] = regg;
                regg = "";
            }

            for (int i = 0; i < 100; i++)
            {
                tabelaReg[i] = new Registracija(nakljucnaObmocja[i], nakljucneReg[i]);
            }
            foreach (var item in tabelaReg)
            {
                Console.WriteLine(item.ToString());
            }
            
            
            Registracija neki = new Registracija("NG", "VGA56");
            //Console.WriteLine(neki);
        }

        private string obmocje;
        private string registrska;
        private static List<string> spisek_obmocij = new List<string>() { "LJ", "KR", "KK", "MB", "MS", "KP", "GO", "CE", "SG", "NM", "PO" };

        /// <summary>
        /// minimalni konstruktor, kki tvori objekt s privzetimi vrednostmi
        /// </summary>
        /// <param name="obmocje"></param>
        /// <param name="registracija"></param>
        public Registracija(string obmocje, string registracija)
        {
            this.obmocje = obmocje;
            this.registrska = registracija;
        }

        //get- set metode

        public string Obmocje
        {
            get { return this.obmocje; }
            set  //če damo = 
            {
                if (value.Length != 2)
                {
                    throw new Exception("Regija je sestavljena iz dveh črk!");
                }
                foreach (char crka in value)
                {
                    if (!char.IsLetter(crka))
                    {
                        throw new Exception("Regija je sestavljena samo iz črk");
                    }
                }
                this.obmocje = value;
            }
        }
        public string Registrska
        {
            get { return this.registrska; }
            set {
                if (this.registrska.Length != 5)
                {
                    throw new Exception("Drugi del registrske oznake je sestavljen iz 5 črk!");
                }
                foreach (char znak in this.registrska)
                {
                    if (!char.IsLetterOrDigit(znak))
                    {
                        throw new Exception("Registrska vsebuje le črke in številke");
                    }
                }


                registrska = value; }
        }


        /// <summary>
        /// metoda bo dodala novo območje v regijo,
        /// za stare nam je vseeno
        /// metoda sprejme tabelo regij, ki jih želimo dodati
        /// </summary>
        /// <param name="nova_regija"></param>
        public void DodajRegjo(ref string[] nova_regija)
        {
            foreach (string obmocje in nova_regija)
            {
                if (!spisek_obmocij.Contains(obmocje))
                {
                    spisek_obmocij.Append(obmocje);
                }
            }

        }

        /// <summary>
        /// metoda ostrani regijo iz tabele spiska območji
        /// </summary>
        /// <param name="regija"></param>
        public void OdstraniRegijo(string regija)
        {
            if (!spisek_obmocij.Contains(regija))
            {
                throw new Exception("Tega območja sploh nimamo!");
            }
            else
            {
                spisek_obmocij.Remove(regija);
            }
        }

        

        /// <summary>
        /// vrne tabelo 
        /// </summary>
        /// <param name="registracije"></param>
        /// <param name="obmocje"></param>
        /// <returns></returns>
        public static void RegistrskeIzRegije(Registracija[] registracije,  string obmocje)
        {
            List<string> izRegije = new List<string>();
            foreach (Registracija elt in registracije)
            {
                if (elt.obmocje == obmocje)
                {
                    izRegije.Add(elt.ToString());
                }
            }
            
            foreach (var registrska in izRegije)
            {
                Console.WriteLine(registrska.ToString());
            }
            
        }

        public static void Najpogostejsa(ref Registracija[] registracije, string kaj = "min")
        {
            Dictionary<string, int> slovarRegistracij = new Dictionary<string, int>();

            foreach (string ob in spisek_obmocij)
            {
                slovarRegistracij[ob] = 0;
            }

            List<string> vse = new List<string>();
            foreach (var item in registracije)
            {
                slovarRegistracij[item.obmocje]++;
            }

            int najveckrat = slovarRegistracij.Values.Max(); //vrednost, ki se največkrat ponovi
            int najmanjkrat = slovarRegistracij.Values.Min();
            string obmocje = "";
            if (kaj == "min")
            {
                foreach (var par in slovarRegistracij)
                {
                    if (par.Value == najveckrat)
                    {
                        obmocje = par.Key;
                    }
                }

            }
            else
            {
                foreach (var par in slovarRegistracij)
                {
                    if (par.Value == najmanjkrat)
                    {
                        obmocje = par.Key;
                    }
                }
            }

            // odstranimo največkrat oz najmanjkrat ponovljene registracije
            slovarRegistracij.Remove(obmocje);

            Registracija[] regi = new Registracija[slovarRegistracij.Count];
            foreach (var reg in registracije)
            {
                if (slovarRegistracij.ContainsKey(reg.obmocje))
                {
                    regi.Append(new Registracija(reg.obmocje, reg.registrska));
                }
                registracije = regi;
            }
        }

            public override string ToString()
        {
            return $"{this.obmocje}{this.registrska}";
        }
    } 
    }
    
   

