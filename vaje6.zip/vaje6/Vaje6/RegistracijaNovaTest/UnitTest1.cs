﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using RegistracijaNova;

namespace RegistracijaNovaTest
{
    [TestClass]
    public class UnitTest1
    {
       
        
        [TestMethod]
        public void TestMethod1()
        {
        }
    }
}
