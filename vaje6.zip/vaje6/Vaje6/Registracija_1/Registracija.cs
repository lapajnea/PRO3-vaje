﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Registracija_1
{
    public  class Registracija
    {
        /// <summary>
        ///
        /// </summary>
        /// 


        private string _obmocje;
        private string _registracija;
        private static string[] spisek_obmocij = new string[] { "LJ", "KR", "KK", "MB", "MS", "KP", "GO", "CE", "SG", "NM", "PO" };

        public Registracija(string obmocje, string registracija)
        {
            this._obmocje = obmocje;
            this._registracija = registracija;
        }


        public string obmocje
        {
            get { return this._obmocje; }
            set
            {
                if (value.Length != 2)
                {
                    throw new Exception("Obmocje mora biti dolzine 2");
                }

                if (!spisek_obmocij.Contains(value))
                {
                    throw new Exception("Obmocje ni na spisku dovoljenih obmocij");
                }

                foreach (char crka in value)
                {
                    if (!char.IsLetter(crka))
                    {
                        throw new Exception("Obmocje mora biti sestavljeno samo iz crk");
                    }
                }
                this._obmocje = value;
            }
        }



        /// <summary>
        /// 
        /// </summary>
        /// <param name="args"></param>
        static void Main(string[] args)
        {
        }
    }
}
