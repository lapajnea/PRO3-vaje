﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using Kosara;

namespace TestKosarica
{
    [TestClass]
    public class TestObjekti
    {
        [TestMethod()]
        public void objekt1()
        {
            Kosarica<string> niz = new Kosarica<string> ("živjo");
            Assert.AreEqual("živjo", niz);
        }
        
    }
}
