﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using Registracija;

namespace TestRegistracija
{
    

    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void preveri_registersko()
        {
            Registracijaa test = new Registracijaa("LJ 16VGA");
            Assert.AreEqual("LJ", test.obmocje);
        }
       
    }
    public class Generator
    {
        

        [TestMethod]
        public void preveri_registersko()
        {
            
        }

    }
}
