﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using Vozila;

namespace TestVozilo
{
    [TestClass]
    public class Poti
    {
        [TestMethod()]
       /// preverimo da ima dovolj goriva za dano pot
       public void dovolj_goriva()
        {
            Vozilo avto = new Vozilo(50, 2.3);
            double[] pot = new double[] { 10, 60, 0, 60, 40, 15 };
            Assert.AreEqual(true, avto.DolzinePoti(pot));
        }

        [TestMethod()]
        /// preverimo da nima dovolj goriva za pot
        public void premalo_goriva()
        {
            Vozilo avto = new Vozilo(50, 2.3);
            double[] pot = new double[] { 100, 40, 120, 400 };
            Assert.AreEqual(true, avto.DolzinePoti(pot));
            
        }
        [TestMethod()]
        /// preverimo ali ima dovolj goriva za pot, če tankamo
        public void brez_tankanja()
        {
            Vozilo avto = new Vozilo(50, 6.5);
            double[] pot = new double[] { 100, 40, 0, 120, 400,60 };
            Assert.AreEqual(769, avto.PreostaliKilometri,1);
        }
        [TestMethod()]
        ///preverimo ali nam sproži izjemo
        public void neagativna_pot()
        {
            Vozilo avto = new Vozilo(50, 5);
            double[] pot = new double[] { 15, 7, -4, 12, 0, 34 };
            Action preveri = () => avto.DolzinePoti(pot);
            Assert.ThrowsException<Exception>(preveri);
        }

        [TestMethod()]
        ///preverimo ali nam sporži izjemo če dvakrat tankamo
        public void dvakrat_tankanje()
        {
            Vozilo avto = new Vozilo(50, 6.5);
            double[] pot = new double[] { 100, 40, 0, 0, 120, 400 };
            Action preveri = () => avto.DolzinePoti(pot);
            Assert.ThrowsException<Exception>(preveri);

        }
        [TestMethod()]
        ///preverimo če nam sproži izjemo če želimo tankati pol avto
        public void tankati_pol()
        {
            Vozilo avto = new Vozilo(50, 6.5);
            double[] pot = new double[] { 0, 40, 0, 120, 400, 60 };
            Action preveri = () => avto.DolzinePoti(pot);
            Assert.ThrowsException<Exception>(preveri);
        }
    }
    [TestClass()]
    public class PrveriVozila
    {
        [TestMethod()]
        public void napacna_kapaciteta()
        {
            Action preveri = () => new Vozilo(-50, 5.3);
            Assert.ThrowsException<Exception>(preveri);
        }

       

        [TestMethod()]
        public void negativna_poraba()
        {
            Action preveri = () => new Vozilo(50, -4.5);
            Assert.ThrowsException<Exception>(preveri);
        }

        [TestMethod()]
        public void poraba_nic()
        {
            Action preveri = () => new Vozilo(50, 0);
            Assert.ThrowsException<Exception>(preveri);
        }
    }
}
