﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;
namespace Vaje6
{
    class Program
    {
        static void Main(string[] args)
        {
            //tu naloži sliko
            Bitmap slika = new Bitmap(@"..\..\slika.jpg");
            //naredi kopijo slike
            Bitmap kopija = (Bitmap)slika.Clone();
            //spremeni kopijo z metodo obrezi_in_obrni
            Bitmap obrnjena = obrezi_in_obrni(slika);
            //shrani kopijo slike 
            obrnjena.Save(@"..\..\ObrnjenaInObrezana_slika.jpg");

            Bitmap zrcalo_slika = zrcalo(slika);
            zrcalo_slika.Save(@"..\..\zrcaljena_slika.jpg");
        }

        /// <summary>
        /// funkcija sliko obreze in obrne za 180 stopnij
        /// </summary>
        /// <param name="slika"></param>
        /// <returns></returns>
        static Bitmap obrezi_in_obrni(Bitmap slika)
        {
            if (slika.Width < 800 || slika.Height < 800)
            {
                Console.WriteLine("Slika je premajhna!");
                return null;
            }
            else {
                Rectangle obrezi = new Rectangle(400, 400, 500, 550);
                Bitmap obrezana_slika = slika.Clone(obrezi, slika.PixelFormat);
                //obrnemo
                obrezana_slika.RotateFlip(RotateFlipType.Rotate180FlipXY);
                return obrezana_slika; }
        }

        static Bitmap zrcalo(Bitmap slika)
        {
            Bitmap zrcaljeno = (Bitmap)slika.Clone();
            for (int i = 0; i < zrcaljeno.Height; i++)
            {
                for (int j = 0; j < zrcaljeno.Width / 2; j++)
                {
                    Color barva = zrcaljeno.GetPixel(zrcaljeno.Width - j - 1, i);
                    zrcaljeno.SetPixel(j, i, barva);
                } }
               
            return zrcaljeno;
            
        }


        
    }
}
