﻿
namespace NasPrviOkenskiProgram
{
    partial class GlOkno
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tb_op1 = new System.Windows.Forms.TextBox();
            this.tb_op2 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.rezultat = new System.Windows.Forms.Label();
            this.gmb_izracun = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // tb_op1
            // 
            this.tb_op1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.tb_op1.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_op1.Location = new System.Drawing.Point(39, 94);
            this.tb_op1.Name = "tb_op1";
            this.tb_op1.Size = new System.Drawing.Size(72, 38);
            this.tb_op1.TabIndex = 0;
            this.tb_op1.Text = "0";
            // 
            // tb_op2
            // 
            this.tb_op2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.tb_op2.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_op2.Location = new System.Drawing.Point(159, 94);
            this.tb_op2.Name = "tb_op2";
            this.tb_op2.Size = new System.Drawing.Size(66, 38);
            this.tb_op2.TabIndex = 1;
            this.tb_op2.Text = "0";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(117, 95);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(36, 37);
            this.label1.TabIndex = 2;
            this.label1.Text = "+";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(231, 95);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(36, 37);
            this.label2.TabIndex = 3;
            this.label2.Text = "=";
            this.label2.MouseHover += new System.EventHandler(this.izracun);
            // 
            // rezultat
            // 
            this.rezultat.AutoSize = true;
            this.rezultat.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rezultat.Location = new System.Drawing.Point(273, 95);
            this.rezultat.Name = "rezultat";
            this.rezultat.Size = new System.Drawing.Size(35, 37);
            this.rezultat.TabIndex = 3;
            this.rezultat.Text = "0";
            this.rezultat.MouseHover += new System.EventHandler(this.izracun);
            // 
            // gmb_izracun
            // 
            this.gmb_izracun.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gmb_izracun.Location = new System.Drawing.Point(250, 306);
            this.gmb_izracun.Name = "gmb_izracun";
            this.gmb_izracun.Size = new System.Drawing.Size(159, 44);
            this.gmb_izracun.TabIndex = 4;
            this.gmb_izracun.Text = "izračun";
            this.gmb_izracun.UseVisualStyleBackColor = true;
            this.gmb_izracun.Click += new System.EventHandler(this.izracun);
            // 
            // GlOkno
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(484, 461);
            this.Controls.Add(this.gmb_izracun);
            this.Controls.Add(this.rezultat);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.tb_op2);
            this.Controls.Add(this.tb_op1);
            this.Name = "GlOkno";
            this.Text = "Seštevalnik";
            this.Load += new System.EventHandler(this.GlOkno_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox tb_op1;
        private System.Windows.Forms.TextBox tb_op2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label rezultat;
        private System.Windows.Forms.Button gmb_izracun;
    }
}

