﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace NasPrviOkenskiProgram
{
    public partial class GlOkno : Form
    {
        public GlOkno()
        {
            InitializeComponent();
        }

        private void GlOkno_Load(object sender, EventArgs e)
        {

        }

        private void izracun(object sender, EventArgs e)
        {
            try
            {
                int r = int.Parse(tb_op1.Text) + int.Parse(tb_op2.Text);
                rezultat.Text = r.ToString();
            }
            catch { }
        }
        

       
    }
}
