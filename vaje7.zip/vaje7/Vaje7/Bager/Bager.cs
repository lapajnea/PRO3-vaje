﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mehanizacija
{
    public class Bager 
    {
        static void Main(string[] args)
        {
        }

        private int teza; // v kg
        private string ime;
        private int leto;
        private int cena;

        /// <summary>
        /// konstruktor bo nastavil privzete vrednosti vrednosti
        /// </summary>
        public Bager()
        {
            this.teza = 4500;
            this.ime = "Primer Bager";
            this.leto = 2000;
            this.cena = 50000;
        }

        // za branje

        /// <summary>
        /// konstruktor za branjte, kjer so podatki ločeni z vejico
        /// tako: teza, ime, leto, cena
        /// </summary>
        /// <param name="podatki_bagra"></param>
        public Bager(string podatki_bagra)
        {
            string[] podatki = podatki_bagra.Split(',');

            try
            {
                teza = int.Parse(podatki[0]);
                ime = podatki[1];
                leto = int.Parse(podatki[2]);
                cena = int.Parse(podatki[3]);
            }
            catch
            {
                throw new Exception("Podatki niso pravilno vnešeni!");
            }
        }

        /// <summary>
        /// če imamo podane vse podatke, jih moramo preveriti
        /// </summary>
        /// <param name="teza"></param>
        /// <param name="ime"></param>
        /// <param name="leto"></param>
        /// <param name="cena"></param>
        public Bager(int teza, string ime, int leto, int cena)
        {
            if (teza <= 0)
            { throw new Exception("Teža mora biti pozitivno število");
                this.ime = ime;
                if (leto < 1900 || leto > DateTime.Now.Year)
                {
                    throw new Exception($"Leto mora biti med 1900 in {DateTime.Now.Year}.");
                }
                this.cena = cena;
            }
        }
        // Izpis

        public override string ToString()
        {
            return $"{this.ime},{this.teza},{this.leto},{this.cena}";
        }

        // branje teže, teže se ne da nastaviti

        public int Teza
        {
            get { return this.teza; }
        }

        //branje cene, cena se da nastaviti
        public int Cena
        {
            get
            { return this.cena; }
            set //če daš = value
            {
                if (value <= 0)
                {
                    throw new Exception("Cena ne more biti 0 ali manj");
                }
                this.cena = value;
            }
        }

        //izpis leta izdelave, in leto se ne sme spreminjati
        public int LetoIzdelave
        {
            get
            {
                return this.leto;
            }
        }
        //branje imena

        public string Ime
        { get { return this.ime; } }

        // upoštevajamo željeno obiko za izpis
        public void Izpis()
        {
            Console.WriteLine($"Bager {this.ime} težek {this.teza} stane {this.cena} EUR");
        }

        //////////////////////
        ///naloge
        ///////////////////
        ///

        ///
        /// poiščemo najtežji bager
        public static void Najtezji(Bager[] tabela_bagrov)
        {
            if (tabela_bagrov.Length == 0)
            {
                throw new Exception("Nimamo nobenega bagra"); 
            }
            Bager najtezji = tabela_bagrov[0]; //s tem bomo primerjali
            foreach (Bager vozilo in tabela_bagrov)
            {
                if (vozilo.Cena > najtezji.Cena)
                {
                    najtezji = vozilo;
                }
            }
            najtezji.Izpis();
        }

        /// <summary>
        /// vse bagre ki so dražji od 20000 pocenimo za 10%
        /// </summary>
        /// <param name="tabela_bagrov"></param>
        public static void Akcija(Bager[] tabela_bagrov)
        {
            if (tabela_bagrov.Length == 0)
            {
                throw new Exception("Nimamo nobenega bagra");
            }
            foreach(Bager vozilo in tabela_bagrov)
            {
                if(vozilo.Cena > 20000)
                {
                    vozilo.Cena = vozilo.Cena - (vozilo.Cena / 10);
                }
            }
        }

        /// <summary>
        /// tabelo bagrov uredi po velikosti
        /// </summary>
        /// <param name="tabela_bagrov"></param>
        public static void Urejeno(ref Bager[] tabela_bagrov)
        {
            Bager[] bagri = new Bager[tabela_bagrov.Length];
            Array.Sort(tabela_bagrov); // uredimo
            int najmlajsi = tabela_bagrov[0].LetoIzdelave;
            for (int i = 0; i < tabela_bagrov.Length; i++)
            {
                if (tabela_bagrov[i].LetoIzdelave != najmlajsi)
                {
                    bagri.Append(tabela_bagrov[i]);
                }
            }
        }
    }
}
