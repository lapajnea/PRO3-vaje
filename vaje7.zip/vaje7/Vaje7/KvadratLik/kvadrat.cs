﻿using System;
using System.Collections.Generic;
using System.IO;

namespace KvadratLik
{
    class kvadrat: IComparable<kvadrat>
    {
        private double Sredisce_x;
        private double Sredisce_y;
        private double Dolzina_stranice;
        static void Main(string[] args)
        {
        }
        
        public kvadrat()
        {
            this.Sredisce_x = 0;
            this.Sredisce_y = 0;
            this.Dolzina_stranice = 1;
        }
        
        public kvadrat(string niz)
        {
            string[] nov_niz = niz.Split(',');
            Sredisce_x = double.Parse(nov_niz[0]);
            Sredisce_y = double.Parse(nov_niz[1]);
            Dolzina_stranice = double.Parse(nov_niz[2]);

            
        }

        public kvadrat(double sredisce_x, double sredisce_y, double stranica)
        {
            this.Sredisce_x = sredisce_x;
            this.Sredisce_y = sredisce_y;
            this.Dolzina_stranice = stranica;
        }

        /// <summary>
        /// branje središča x
        /// </summary>
        public double Srediscex
        {
            get { return this.Sredisce_x; }
        }
        /// <summary>
        /// branje središčay
        /// </summary>
        public double Srediscey
        {
            get { return this.Sredisce_y; }
        }

        /// <summary>
        /// branje dolžine stranice
        /// </summary>
        public double stranica
        {
            get { return this.Dolzina_stranice; }
            set
            {
                if (value < 0)
                {
                    throw new Exception("dolžina mora biti pozitivna!");
                }
                this.Dolzina_stranice = value;
            }
        }
            public override string ToString()
        {
            return $"{this.Sredisce_x};{this.Sredisce_x};{this.Dolzina_stranice}";
        }

        /// <summary>
        /// računanje obsega kvadrata
        /// </summary>
        /// <param name="kvadrat"></param>
        /// <returns></returns>
        public static double obseg(kvadrat kvadrat)
        {
            return kvadrat.Dolzina_stranice * 4;
        }

        /// <summary>
        /// računanje ploscine kvadrata
        /// </summary>
        /// <param name="kvadrat"></param>
        /// <returns></returns>
        public static double ploscina(kvadrat kvadrat)
        {
            return kvadrat.Dolzina_stranice * kvadrat.Dolzina_stranice;
        }

        /// <summary>
        /// pisanje na datoteko
        /// </summary>
        /// <param name="datoteka"></param>
        public void na_datoteko(StreamWriter datoteka)
        {
            datoteka.Write(this.ToString());
            datoteka.Close();
        }

        /// <summary>
        /// branje iz datoteke
        /// </summary>
        /// <param name="datoteka"></param>
        /// <returns></returns>
        public List<kvadrat> beri_iz_datoteke(string datoteka)
        {
            StreamReader dat = new StreamReader(datoteka);
            List<kvadrat> kvadrati = new List<kvadrat>();

            while (!dat.EndOfStream)
            {
                string beri = dat.ReadLine();
                kvadrat ena = new kvadrat(beri);
            }
            dat.Close();
            return kvadrati;
        }

        public void izpis_na_datoteko(string datoteka)
        {
            StreamReader dat = new StreamReader(datoteka);

            while (!dat.EndOfStream)
            {
                string beri = dat.ReadLine();
                Console.WriteLine(beri);
            }
            dat.Close();
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="kvadrati"></param>
        /// <returns></returns>
        public static double povrsina_tabele(kvadrat[] kvadrati)
        {
            double povrsina = ploscina(kvadrati[0]);
            for (int i = 1; i < kvadrati.Length; i++)
            {
                povrsina += ploscina(kvadrati[i]);
                for (int j = 0; j < i; j++)
                {
                    if (AliSePrekriva(kvadrati[i], kvadrati[j]))
                    // prekriva na eni izmed strani
                    {
                        povrsina -= Prekrivanje(kvadrati[i], kvadrati[j]);
                    }
                }
            }

            return povrsina;
        }

        public static bool AliSePrekriva(kvadrat prvi, kvadrat drugi)
        {
            double[] prviLevoZgoraj = { prvi.Sredisce_x + prvi.Dolzina_stranice / 2, prvi.Sredisce_y + prvi.Dolzina_stranice / 2 };
            double[] drugiLevoZgoraj = { drugi.Sredisce_x + drugi.Dolzina_stranice/ 2, drugi.Sredisce_y + drugi.Dolzina_stranice / 2 };
            double[] prviDesnoSpodaj = { prvi.Sredisce_x - prvi.Dolzina_stranice / 2, prvi.Sredisce_y - prvi.Dolzina_stranice / 2 };
            double[] drugiDesnoSpodaj = { drugi.Sredisce_x - drugi.Dolzina_stranice / 2, drugi.Sredisce_y - drugi.Dolzina_stranice / 2 };

           
            if (prviLevoZgoraj[0] >= drugiDesnoSpodaj[0] || drugiLevoZgoraj[0] >= prviDesnoSpodaj[0])
            {
                return false;
            }

            if (prviLevoZgoraj[1] <= drugiDesnoSpodaj[1] || drugiLevoZgoraj[0] <= prviDesnoSpodaj[1])
            {
                return false;
            }
            return true;
        }

        /// <summary>
        /// vrne koliko skupne površine imata dobljena kvadrata
        /// </summary>
        public static double Prekrivanje(kvadrat prvi, kvadrat drugi)
        {
            double razdaljaX = prvi.Sredisce_x - drugi.Sredisce_x;
            double razdaljaY = prvi.Sredisce_y - drugi.Sredisce_y;
            double koliko = 0;
            if (razdaljaX < 0) // prvi x je manjši
            {
                if (razdaljaY < 0) // tudi y prvega je manjši
                {
                    koliko = Math.Abs(prvi.Sredisce_x + prvi.Dolzina_stranice / 2 - drugi.Sredisce_x - drugi.Dolzina_stranice / 2) *
                             Math.Abs(prvi.Sredisce_y + prvi.Dolzina_stranice / 2 - drugi.Sredisce_y - drugi.Dolzina_stranice / 2);
                }
                else
                {
                    koliko = Math.Abs(prvi.Sredisce_x + prvi.Dolzina_stranice / 2 - drugi.Sredisce_x - drugi.Dolzina_stranice / 2) *
                             Math.Abs(prvi.Sredisce_y - prvi.Dolzina_stranice / 2 - drugi.Sredisce_y + drugi.Dolzina_stranice / 2);
                }
            }
            else
            {
                if (razdaljaY < 0) // y prvega je manjši
                {
                    koliko = Math.Abs(prvi.Sredisce_x - prvi.Dolzina_stranice / 2 - drugi.Sredisce_x + drugi.Dolzina_stranice / 2) *
                             Math.Abs(prvi.Sredisce_y + prvi.Dolzina_stranice / 2 - drugi.Sredisce_y - drugi.Dolzina_stranice / 2);
                }
                else
                {
                    koliko = Math.Abs(prvi.Sredisce_x - prvi.Dolzina_stranice / 2 - drugi.Sredisce_x + drugi.Dolzina_stranice / 2) *
                             Math.Abs(prvi.Sredisce_y- prvi.Dolzina_stranice / 2 - drugi.Sredisce_y + drugi.Dolzina_stranice / 2);
                }
            }
            return koliko;
        }

        /// <summary>
        /// kvadratom, ki imajo obseg manjši od 10% povprečje, spremeni velikost stranice, da bo kvadrat toliko velik kot je povprečje
        /// </summary>
        /// <param name="tab">tabela kvadratovkatero spremenimo</param>
        public static void MinimumNaPovprecje(ref kvadrat[] tab)
        {
            int koliko = tab.Length;
            double vsotaObsegov = 0;
            //najprej izračunamo povprečje
            foreach (kvadrat elt in tab)
            {
                vsotaObsegov += obseg(elt);
            }
            double povprecje = vsotaObsegov / koliko;
            foreach (kvadrat elt in tab)
            {
                if (obseg(elt) / povprecje < 0.1)
                {
                    elt.Dolzina_stranice = povprecje / 4;
                }
            }
        }

        //problem po lastni izberi
        public static bool operator <(kvadrat levi, kvadrat desni)
        {
            double ploscinaLevi = ploscina(levi);
            double ploscinaDesni = ploscina(desni);
            if (ploscinaLevi == ploscinaDesni)
            {
                return true;
            }
            else
            {
                return ploscinaLevi < ploscinaDesni;
            }
        }
        public static bool operator >(kvadrat levi, kvadrat desni)
        {
            return !(levi < desni);
        }
        public int CompareTo(kvadrat desni)
        {
            return ploscina(this).CompareTo(ploscina(desni));
        }
    }
}
    }

