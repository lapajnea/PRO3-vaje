﻿
namespace LeviInDesni
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.bt_levi = new System.Windows.Forms.Button();
            this.bt_desni = new System.Windows.Forms.Button();
            this.lb_izpis = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // bt_levi
            // 
            this.bt_levi.Location = new System.Drawing.Point(18, 27);
            this.bt_levi.Name = "bt_levi";
            this.bt_levi.Size = new System.Drawing.Size(78, 24);
            this.bt_levi.TabIndex = 0;
            this.bt_levi.Text = "Levi";
            this.bt_levi.UseVisualStyleBackColor = true;
            this.bt_levi.MouseDown += new System.Windows.Forms.MouseEventHandler(this.bt_levi_MouseDown);
            this.bt_levi.MouseUp += new System.Windows.Forms.MouseEventHandler(this.bt_levi_MouseUp);
            // 
            // bt_desni
            // 
            this.bt_desni.Location = new System.Drawing.Point(342, 27);
            this.bt_desni.Name = "bt_desni";
            this.bt_desni.Size = new System.Drawing.Size(78, 24);
            this.bt_desni.TabIndex = 0;
            this.bt_desni.Text = "Desni";
            this.bt_desni.UseVisualStyleBackColor = true;
            this.bt_desni.MouseDown += new System.Windows.Forms.MouseEventHandler(this.bt_desni_MouseDown);
            this.bt_desni.MouseUp += new System.Windows.Forms.MouseEventHandler(this.bt_desni_MouseUp);
            // 
            // lb_izpis
            // 
            this.lb_izpis.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_izpis.Location = new System.Drawing.Point(102, 31);
            this.lb_izpis.Name = "lb_izpis";
            this.lb_izpis.Size = new System.Drawing.Size(234, 20);
            this.lb_izpis.TabIndex = 1;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(484, 67);
            this.Controls.Add(this.lb_izpis);
            this.Controls.Add(this.bt_desni);
            this.Controls.Add(this.bt_levi);
            this.Name = "Form1";
            this.Text = "Levi in desni";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button bt_levi;
        private System.Windows.Forms.Button bt_desni;
        private System.Windows.Forms.Label lb_izpis;
    }
}

