﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LeviInDesni
{
    public partial class Form1 : Form
    {
        private string ZacSt = "NIČ";
        public Form1()
        {
            InitializeComponent();
        }

        private void bt_levi_MouseDown(object sender, MouseEventArgs e)
        {
            lb_izpis.Text = "<- levi pritisnjen";
        }

        private void bt_levi_MouseUp(object sender, MouseEventArgs e)
        {
            lb_izpis.Text = this.ZacSt;
        }

        private void bt_desni_MouseDown(object sender, MouseEventArgs e)
        {
            lb_izpis.TextAlign = ContentAlignment.MiddleRight;
            lb_izpis.Text = "desni pritisnjen->";
        }

        private void bt_desni_MouseUp(object sender, MouseEventArgs e)
        {
            lb_izpis.Text = this.ZacSt;
            lb_izpis.TextAlign = ContentAlignment.TopRight;
        }
    }
}
