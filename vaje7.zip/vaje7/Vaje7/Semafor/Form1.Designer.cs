﻿
namespace Semafor
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.bt_rdeca = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.bt_zelena = new System.Windows.Forms.Button();
            this.lb_barva = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // bt_rdeca
            // 
            this.bt_rdeca.Location = new System.Drawing.Point(21, 24);
            this.bt_rdeca.Name = "bt_rdeca";
            this.bt_rdeca.Size = new System.Drawing.Size(89, 30);
            this.bt_rdeca.TabIndex = 0;
            this.bt_rdeca.Text = "Rdeča";
            this.bt_rdeca.UseVisualStyleBackColor = true;
            this.bt_rdeca.Click += new System.EventHandler(this.bt_rdeca_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(21, 60);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(89, 30);
            this.button2.TabIndex = 0;
            this.button2.Text = "Rumena";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // bt_zelena
            // 
            this.bt_zelena.Location = new System.Drawing.Point(21, 96);
            this.bt_zelena.Name = "bt_zelena";
            this.bt_zelena.Size = new System.Drawing.Size(89, 30);
            this.bt_zelena.TabIndex = 0;
            this.bt_zelena.Text = "Zelena";
            this.bt_zelena.UseVisualStyleBackColor = true;
            this.bt_zelena.Click += new System.EventHandler(this.bt_zelena_Click);
            // 
            // lb_barva
            // 
            this.lb_barva.Font = new System.Drawing.Font("Microsoft Sans Serif", 52F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_barva.Location = new System.Drawing.Point(128, 24);
            this.lb_barva.Name = "lb_barva";
            this.lb_barva.Size = new System.Drawing.Size(99, 95);
            this.lb_barva.TabIndex = 1;
            this.lb_barva.Text = "    ";
            this.lb_barva.Click += new System.EventHandler(this.lb_barva_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(251, 144);
            this.Controls.Add(this.lb_barva);
            this.Controls.Add(this.bt_zelena);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.bt_rdeca);
            this.Name = "Form1";
            this.Text = "Semafor";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button bt_rdeca;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button bt_zelena;
        private System.Windows.Forms.Label lb_barva;
    }
}

