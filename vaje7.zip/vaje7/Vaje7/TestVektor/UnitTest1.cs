﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using VektorIme;

namespace TestVektor
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {
            Vektor test = new Vektor(3, 2, 1);
            Assert.AreEqual(test.komponenta_x, 3);
            ///Assert.AreEqual(test.komponenta_y, 2);
           /// Assert.AreEqual(test.komponenta_z, 1);
        }

     ///   [TestMethod]
      ///  public void TestMethod2()
       /// {
       ///     Action test = (() => new Vektor(3, 2, -5));
       ///     Assert.ThrowsException<new Exception>(true);
       /// }
        [TestMethod()]
        public void TestMethod3()
        {
            Vektor a = new Vektor(7,2,1);
            Vektor b = new Vektor(3,3,3);
            Vektor c = a + b;
            Assert.AreEqual(c.komponenta_x, 10);
            Assert.AreEqual(c.komponenta_y, 5);
            Assert.AreEqual(c.komponenta_z, 4);
        }
        [TestMethod()]
        public void TestMethod4()
        {
            Vektor a = new Vektor(1, 2, 3);
            Vektor b = new Vektor(6, 4, 9);
            Vektor c = a + b;
            Assert.AreEqual(c.ToString(), "(7, 6, 12)");
        }
        [TestMethod()]
        public void TestMethod5()
        {
            Vektor a = new Vektor(1, 2, 3);
            Vektor b = new Vektor(6, 4, 9);
            Vektor c = a + b;
            Assert.AreEqual(c.Dolzina, Math.Pow(229, 0.5));
        }
    }
}

