﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using VektorIme;
using Vozila;

using System.Threading.Tasks;

namespace Urejanje_objektov
{
    class Program
    {

        static void Main(string[] args)
        {
            /// Console.WriteLine("zivjo!");
            TestVozilo();
        }
        public static Random rng = new Random();


        /// <summary>
        /// Generiramo tabelo objektov danega razreda.
        /// Tabelo naredi za 3 večjo,
        /// kot boš generiral elementov
        /// </summary>
        private static void TestVektor()
        {
            Vektor[] tabela_vektorjev = new Vektor[13];
            for (int i = 0; i < tabela_vektorjev.Length - 3; i++)
            {
                int elementx = rng.Next();
                int elementy = rng.Next();
                int elementz = rng.Next();
                tabela_vektorjev[i] = new Vektor(elementx, elementy, elementz);
            }
            ///dodamo kopijo 3. 5. in se enkrat 3. elementa
            ///
            int dolzina = tabela_vektorjev.Length;
            tabela_vektorjev[dolzina - 3] = new Vektor(tabela_vektorjev[2].komponenta_x, tabela_vektorjev[2].komponenta_y, tabela_vektorjev[2].komponenta_z);
            tabela_vektorjev[dolzina - 2] = new Vektor(tabela_vektorjev[4].komponenta_x, tabela_vektorjev[4].komponenta_y, tabela_vektorjev[4].komponenta_z);
            tabela_vektorjev[dolzina - 1] = new Vektor(tabela_vektorjev[2].komponenta_x, tabela_vektorjev[2].komponenta_y, tabela_vektorjev[2].komponenta_z);

            izpis_tabele(tabela_vektorjev);
            Array.Sort(tabela_vektorjev);
            izpis_tabele(tabela_vektorjev);
            
        }

        private static void TestVozilo()
        {
            Vozilo[] tabela_vozil = new Vozilo[13];
            for (int i = 0; i < tabela_vozil.Length - 3; i++)
            {
                double poraba = rng.NextDouble() * 15;
                double kapaciteta = rng.NextDouble() * 80 + 15;
                tabela_vozil[i] = new Vozilo(kapaciteta, poraba);
            }
            tabela_vozil[tabela_vozil.Length - 3] = new Vozilo(tabela_vozil[2].Kapaciteta, tabela_vozil[2].Poraba);
            tabela_vozil[tabela_vozil.Length - 2] = new Vozilo(tabela_vozil[4].Kapaciteta, tabela_vozil[4].Poraba);
            tabela_vozil[tabela_vozil.Length - 1] = new Vozilo(tabela_vozil[2].Kapaciteta, tabela_vozil[2].Poraba);

            izpis_tabele(tabela_vozil);
            Array.Sort(tabela_vozil);
            izpis_tabele(tabela_vozil);
        }
        private static void izpis_tabele<T>(T[] tabela)
        {
            Console.WriteLine("Izpis:");
            for (int i = 0; i < tabela.Length; i++)
            {
                if (tabela[i] != null)
                {

                    Console.WriteLine(tabela[i]);
                }
            }
        }
    }
}
