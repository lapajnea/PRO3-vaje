﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Vozila
{
    /// <summary>
    /// gorivo in kapaciteto imamo v litrih, porabo pa v litrih
    /// na 100km
    /// </summary>
    public class Vozilo
    {
        private double gorivo;
        private double kapaciteta;
        private double poraba;

        static void Main(string[] args)
        {
           
        }

        //konstruktor

    public Vozilo(double kapaciteta, double poraba)
        {
            this.gorivo = kapaciteta;
            this.kapaciteta = kapaciteta;
            this.poraba = poraba;

            if(kapaciteta < 0) {
                throw new Exception("Kapaciteta goriva ne more biti negativna!");
            }
            if (poraba <= 0)
            {
                throw new Exception("Poraba goriva ne more biti negativna ali 0!");

            }
        }

        public override string ToString()
        {
            return $"Kapaciteta tanka {this.kapaciteta}, preostalo gorivo {this.gorivo}, poraba pa je {this.poraba}. ";
        }
        //dodamo lastnost
        /// <summary>
        /// koliko kilometrov še lahko prevozimo z gorivom, ki ga imamo
        /// </summary>
        public double PreostaliKilometri
        {
            get { return (this.gorivo / this.poraba) *100; }
        }

        // napišemo metodo
        public void Crpalka()
        {
            this.gorivo = this.kapaciteta;
        }
        /// <summary>
        /// funkcija sprejeme tabelo dolžin poti v km, ki jih želimo
        /// opraviti. Število 0 pomeni točenje gorica
        /// izjeme sprožimo če:
        /// imamo v tabeli negativno število
        /// če moramo dvakrat tankati
        /// </summary>
        /// <param name="PotiKm"></param>
        /// <returns></returns>
        public bool DolzinePoti(double[] PotiKm)
        {
            double koliko_goriva = this.gorivo;
            foreach (double pot in PotiKm)
            {
                if (pot < 0)
                {
                    throw new Exception("Pot ne more biti negativna!");
                }
                if (pot == 0) //tu preverim če je tank poln in če imamo več zaporednih 0
                {
                    if(koliko_goriva == this.kapaciteta)
                    {
                        throw new Exception("Tank je poln, ni potrebno tankati!");
                    }
                    else { koliko_goriva = this.kapaciteta; }
                }
                //koliko goriva nam ostane po prevoženi poti
                koliko_goriva = koliko_goriva - pot / 100 * this.poraba;
                if (koliko_goriva < 0)
                {
                    return false; // ne moremo prevoziti
                }
                else { continue; }
            }
            this.gorivo = koliko_goriva;
            return true;
            
        }
    }
}
