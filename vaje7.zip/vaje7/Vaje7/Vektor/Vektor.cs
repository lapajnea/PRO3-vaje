﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VektorIme
{
    public class Vektor 
    {
        private int x;
        private int y;
        private int z;
        static void Main(string[] args)
        {
        }

        public Vektor(int a, int b, int c)
        {
            this.x = a;
            this.y = b;
            this.z = c;
        }

        //branje oz izpis

        public int komponenta_x
        {
            get { return this.x; }
            set
            {
                if (value < 0)
                {
                    throw new Exception("Vektor mora biti v prvem oktantu");
                }
                this.x = value;
            }
        }

        public int komponenta_y
        {
            get { return this.y; }
            set
            {
                if (value < 0)
                {
                    throw new Exception("Vektor mora biti v prvem oktantu");
                }
                this.y = value;
            }
        }
        public int komponenta_z
        {
            get { return this.z; }
            set
            {
                if (value < 0)
                {
                  throw new Exception("Vektor mora biti v prvem oktantu");
                }
                this.z = value;
            }

        }

        //dodamo javno lastnost dolzina, ki se je do brati, ne da pa spreminjati,
        //zato nimamo set 
        /// <summary>
        /// vrne dolzino vektorja
        /// </summary>
        public double Dolzina
        {
            get { return Math.Pow(Math.Pow(this.x, 2) + Math.Pow(this.y, 2) + Math.Pow(this.z, 2), 0.5); }
        }

        public override string ToString()
        {
            return $"({this.x}, {this.y}, {this.z})";
        }

       /// <summary>
       /// definiramo operator +, ki usterzno sešteje dva vektorja, po komponentah
       /// </summary>
       /// <param name="v1"></param>
       /// <param name="v2"></param>
       /// <returns></returns>
       public static Vektor operator + (Vektor v1, Vektor v2)
        {
            Vektor u = new Vektor(v1.x + v2.x, v1.y + v2.y, v1.z + v2.z);
            return u;
        }
    }
}
