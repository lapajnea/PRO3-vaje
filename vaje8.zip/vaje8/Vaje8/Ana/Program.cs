﻿using System;
using System.Collections;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace Ana
{
    class Program
    {
        static void Main(string[] args)
        {
//            Zapiši pravilo za urejanje, ki bo imena uredila glede na število črk "a", ki se
//nahajajo v imenu.Če imata dve imeni enako število črk "a" ju uredi po dolžini; če sta tudi tu
//dve imeni enaki, ju uredi leksikografsko.Vrni urejeno tabelo Array.
//Pravilo lahko zapišeš za Array in ArrayList najprej pretvoriš v Array; ali pa pravilo za urejanje
//zapišeš za ArrayList in nato že urejen seznam pretvoriš v tabelo.

            ArrayList imena = new ArrayList();
            imena.Add("Marija");
            imena.Add("Ana");
            imena.Add("Maja");
            imena.Add("Irena");
            imena.Add("Mojca");
            imena.Add("Nina");
            imena.Add("Mateja");
            imena.Add("Nataša");
            imena.Add("Andreja");
            imena.Add("Barbara");

            IComparer primerjaj = new Sortiraj();
            imena.Sort(primerjaj);
            foreach (var ime in imena)
            {
                Console.WriteLine(ime);
            }

            
        }
        public class Sortiraj : IComparer {
            public int Compare(object prvi, object drugi)
            {
                int prviA = prvi.ToString().ToLower().Split('a').Length - 1;
                int drugiA = drugi.ToString().ToLower().Split('a').Length - 1;

                if (prviA == drugiA)
                {
                    int prviAA = prvi.ToString().Length;
                    int drugiAA = drugi.ToString().Length;

                    if (prviAA == drugiAA)
                    {
                        return prvi.ToString().CompareTo(drugi.ToString());
                    }
                    return prviAA.CompareTo(drugiAA);
                }
                return prviA.CompareTo(drugiA);
            } }
    }
}
