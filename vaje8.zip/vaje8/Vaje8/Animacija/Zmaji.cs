﻿using System;
using System.Windows.Forms;


// Ime slike rdečega zmaja: rdeci_zmaj
// Ime slike zelenega zmaja: zeleni_zmaj

// 1.NALOGA

// Na začetku ustvari timer, nato napiši program, v katerem se bosta zmaja srečala. 
// Pri tem upoštevaj, da je rdeči zmaj močnejši in bo premagal zelenega.
// To pokažeš na tak način, da ob srečanju zmajev zeleni zmaj izgine, rdeči pa odleti naprej.
// Zaželeno je, da začetnih položajev zmajev ne spreminjaš.

// Namig: Za premike uporabi kombinacijo: premik.Left in premik.Top
// npr: premik.Left += 1, premik.Top -= 1; 



// 2.NALOGA (dodatek prvi nalogi)

// V Design dodaj še poljubno število diamantov. Najdeš jih v Animacija\Animacija\bin\Debug.
// Za vsakega izmed zmajev naj se v zgornjem levem, oziroma desnem kotu izpiše število diamantov, ki jih je osvojil.
// Sedaj je močnejši tisti zmaj, ki ima več diamantov. Ob srečanju izgine slabši.




namespace Animacija
{
    public partial class Zmaji : Form
    {
        public Zmaji()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void timer_zmaji_Tick(object sender, EventArgs e)
        {
            
            timer_zmaji.Start();
            rdeci_zmaj.Left -= 2;
            rdeci_zmaj.Top -= 1;
            zeleni_zmaj.Left += 2;
            zeleni_zmaj.Top += 1;

           

            for (int i = 0; i < rdeci_zmaj.Width; i++)
            {
                if (rdeci_zmaj.Bounds.IntersectsWith(zeleni_zmaj.Bounds))
                {
                    zeleni_zmaj.Hide();
                }
            }
        }
    }
}

