﻿
namespace IzmenjavaBarv
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.barve = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.spreminjanje_barv = new System.Windows.Forms.Timer(this.components);
            this.st_oranzna = new System.Windows.Forms.Label();
            this.st_zelena = new System.Windows.Forms.Label();
            this.st_vijolicna = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // barve
            // 
            this.barve.Location = new System.Drawing.Point(47, 67);
            this.barve.Name = "barve";
            this.barve.Size = new System.Drawing.Size(126, 49);
            this.barve.TabIndex = 0;
            // 
            // button1
            // 
            this.button1.AutoSize = true;
            this.button1.Location = new System.Drawing.Point(314, 163);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(114, 28);
            this.button1.TabIndex = 1;
            this.button1.Text = "prekini / nadaljuj";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.prekini);
            // 
            // spreminjanje_barv
            // 
            this.spreminjanje_barv.Enabled = true;
            this.spreminjanje_barv.Interval = 500;
            this.spreminjanje_barv.Tick += new System.EventHandler(this.spreminjanje_barv_Tick);
            // 
            // st_oranzna
            // 
            this.st_oranzna.AutoSize = true;
            this.st_oranzna.Location = new System.Drawing.Point(137, 153);
            this.st_oranzna.Name = "st_oranzna";
            this.st_oranzna.Size = new System.Drawing.Size(13, 13);
            this.st_oranzna.TabIndex = 2;
            this.st_oranzna.Text = "0";
            // 
            // st_zelena
            // 
            this.st_zelena.AutoSize = true;
            this.st_zelena.Location = new System.Drawing.Point(137, 184);
            this.st_zelena.Name = "st_zelena";
            this.st_zelena.Size = new System.Drawing.Size(13, 13);
            this.st_zelena.TabIndex = 2;
            this.st_zelena.Text = "0";
            // 
            // st_vijolicna
            // 
            this.st_vijolicna.AutoSize = true;
            this.st_vijolicna.Location = new System.Drawing.Point(137, 210);
            this.st_vijolicna.Name = "st_vijolicna";
            this.st_vijolicna.Size = new System.Drawing.Size(13, 13);
            this.st_vijolicna.TabIndex = 2;
            this.st_vijolicna.Text = "0";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(50, 150);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(62, 20);
            this.textBox1.TabIndex = 3;
            this.textBox1.Text = "ORANŽNA";
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(50, 181);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(62, 20);
            this.textBox2.TabIndex = 3;
            this.textBox2.Text = "ZELENA";
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(50, 207);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(62, 20);
            this.textBox3.TabIndex = 3;
            this.textBox3.Text = "VIJOLIČNA";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(453, 256);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.st_vijolicna);
            this.Controls.Add(this.st_zelena);
            this.Controls.Add(this.st_oranzna);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.barve);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label barve;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Timer spreminjanje_barv;
        private System.Windows.Forms.Label st_oranzna;
        private System.Windows.Forms.Label st_zelena;
        private System.Windows.Forms.Label st_vijolicna;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox3;
    }
}

