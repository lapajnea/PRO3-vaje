﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace IzmenjavaBarv
{
    public partial class Form1 : Form
    { 
        Random rnd = new Random();
        int stevecKlikov = 0;
        int stevec_zelenih = 0;
        public Form1()
        {
            InitializeComponent();
        }

        private void spreminjanje_barv_Tick(object sender, EventArgs e)
        {
           
            string[] ozadje = { "orange", "green", "purple" };
          
            int st = rnd.Next(3);
            barve.BackColor = Color.FromName(ozadje[st]);
            if(ozadje[st] == "orange")
            {
                st_oranzna.Text = (int.Parse(st_oranzna.Text) + 1).ToString();

            }
            if (ozadje[st] == "green")
            {
                stevec_zelenih++;
                st_zelena.Text = stevec_zelenih.ToString();

            }
            if (ozadje[st] == "purple")
            {
                st_vijolicna.Text = (int.Parse(st_vijolicna.Text) + 1).ToString();

            }

        }

        private void prekini(object sender, EventArgs e)
        {

            spreminjanje_barv.Enabled = !spreminjanje_barv.Enabled;
            stevecKlikov++;
            if (stevecKlikov % 2 == 0)
            { //kqaj na parne klike
              //
            }
            else
            {
                // kaj na lihe klike
            }
     
        }
    }
}
