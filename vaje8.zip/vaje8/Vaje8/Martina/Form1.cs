﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Martina
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            Graphics platno;
            platno = this.CreateGraphics();
            Pen pisalo = new Pen(Color.Black, 10);
            platno.DrawEllipse(pisalo, 50, 50, 100, 100);
            pisalo.Color = Color.Red;
            platno.DrawEllipse(pisalo, 25, 25, 150, 150);
        }
    }
}
