﻿
namespace Odstevalnik
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.stevilo = new System.Windows.Forms.Label();
            this.gmb_ponastavi = new System.Windows.Forms.Button();
            this.gnb_ustavi = new System.Windows.Forms.Button();
            this.gmb_zacni = new System.Windows.Forms.Button();
            this.zacni_cas = new System.Windows.Forms.Timer(this.components);
            this.SuspendLayout();
            // 
            // stevilo
            // 
            this.stevilo.Font = new System.Drawing.Font("Microsoft Sans Serif", 72F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.stevilo.Location = new System.Drawing.Point(113, 47);
            this.stevilo.Name = "stevilo";
            this.stevilo.Size = new System.Drawing.Size(95, 105);
            this.stevilo.TabIndex = 0;
            this.stevilo.Text = "9";
            // 
            // gmb_ponastavi
            // 
            this.gmb_ponastavi.Location = new System.Drawing.Point(30, 180);
            this.gmb_ponastavi.Name = "gmb_ponastavi";
            this.gmb_ponastavi.Size = new System.Drawing.Size(66, 26);
            this.gmb_ponastavi.TabIndex = 1;
            this.gmb_ponastavi.Text = "Ponastavi";
            this.gmb_ponastavi.UseVisualStyleBackColor = true;
            this.gmb_ponastavi.Click += new System.EventHandler(this.gmb_ponastavi_Click);
            // 
            // gnb_ustavi
            // 
            this.gnb_ustavi.Location = new System.Drawing.Point(122, 180);
            this.gnb_ustavi.Name = "gnb_ustavi";
            this.gnb_ustavi.Size = new System.Drawing.Size(66, 26);
            this.gnb_ustavi.TabIndex = 1;
            this.gnb_ustavi.Text = "Ustavi";
            this.gnb_ustavi.UseVisualStyleBackColor = true;
            this.gnb_ustavi.Click += new System.EventHandler(this.gnb_ustavi_Click);
            // 
            // gmb_zacni
            // 
            this.gmb_zacni.Location = new System.Drawing.Point(220, 180);
            this.gmb_zacni.Name = "gmb_zacni";
            this.gmb_zacni.Size = new System.Drawing.Size(66, 26);
            this.gmb_zacni.TabIndex = 1;
            this.gmb_zacni.Text = "Začni";
            this.gmb_zacni.UseVisualStyleBackColor = true;
            this.gmb_zacni.Click += new System.EventHandler(this.gmb_zacni_Click);
            // 
            // zacni_cas
            // 
            this.zacni_cas.Enabled = true;
            this.zacni_cas.Interval = 1000;
            this.zacni_cas.Tick += new System.EventHandler(this.zacni_cas_Tick);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(353, 322);
            this.Controls.Add(this.gmb_zacni);
            this.Controls.Add(this.gnb_ustavi);
            this.Controls.Add(this.gmb_ponastavi);
            this.Controls.Add(this.stevilo);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label stevilo;
        private System.Windows.Forms.Button gmb_ponastavi;
        private System.Windows.Forms.Button gnb_ustavi;
        private System.Windows.Forms.Button gmb_zacni;
        private System.Windows.Forms.Timer zacni_cas;
    }
}

