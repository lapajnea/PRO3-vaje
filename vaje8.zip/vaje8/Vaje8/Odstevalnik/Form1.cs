﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Odstevalnik
{
    public partial class Form1 : Form
    {
        int st = 9;
        public Form1()
        {
            InitializeComponent();
        }

        private void gmb_zacni_Click(object sender, EventArgs e)
        {
            zacni_cas.Start();

        }

        private void zacni_cas_Tick(object sender, EventArgs e)
        {
            //int st = int.Parse(stevilo.Text);
            stevilo.Text = (st - 1).ToString();
            st--;
           if (st == 0)
            {
                zacni_cas.Stop();
            }
            if (zacni_cas.Enabled == false) {
                MessageBox.Show("Ponastavi!");
            }
        }

        private void gmb_ponastavi_Click(object sender, EventArgs e)

        {   if (zacni_cas.Enabled == true)
            {
                zacni_cas.Stop();
                MessageBox.Show("Klikni gumb ustavi ali počakaj do konca!");
            }
            else if(zacni_cas.Enabled == false)
            {
                stevilo.Text = "9";
                st = 10;
            }
          //  zacni_cas.Start();
        }

        private void gnb_ustavi_Click(object sender, EventArgs e)
        {
            zacni_cas.Stop();
            zacni_cas.Enabled = false;
        }
    }
}
