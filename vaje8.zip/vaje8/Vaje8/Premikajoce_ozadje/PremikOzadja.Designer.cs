﻿
namespace Premikajoce_ozadje
{
    partial class PremikOzadja
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.decek = new System.Windows.Forms.PictureBox();
            this.slika1 = new System.Windows.Forms.PictureBox();
            this.slika2 = new System.Windows.Forms.PictureBox();
            this.ozadje = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.decek)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.slika1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.slika2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ozadje)).BeginInit();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(53, 28);
            this.button1.Margin = new System.Windows.Forms.Padding(2);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(85, 36);
            this.button1.TabIndex = 1;
            this.button1.Tag = "fiksno";
            this.button1.Text = "Start";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(53, 68);
            this.button2.Margin = new System.Windows.Forms.Padding(2);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(85, 37);
            this.button2.TabIndex = 2;
            this.button2.Tag = "fiksno";
            this.button2.Text = "Pavza";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Interval = 20;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // decek
            // 
            this.decek.Image = global::Premikajoce_ozadje.Properties.Resources.decek;
            this.decek.Location = new System.Drawing.Point(53, 163);
            this.decek.Name = "decek";
            this.decek.Size = new System.Drawing.Size(76, 91);
            this.decek.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.decek.TabIndex = 4;
            this.decek.TabStop = false;
            // 
            // slika1
            // 
            this.slika1.Cursor = System.Windows.Forms.Cursors.Default;
            this.slika1.Image = global::Premikajoce_ozadje.Properties.Resources.ynoio;
            this.slika1.Location = new System.Drawing.Point(588, 78);
            this.slika1.Margin = new System.Windows.Forms.Padding(2);
            this.slika1.Name = "slika1";
            this.slika1.Size = new System.Drawing.Size(66, 64);
            this.slika1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.slika1.TabIndex = 3;
            this.slika1.TabStop = false;
            this.slika1.Tag = "z_ozadjem";
            // 
            // slika2
            // 
            this.slika2.Image = global::Premikajoce_ozadje.Properties.Resources.ynoio;
            this.slika2.Location = new System.Drawing.Point(755, 163);
            this.slika2.Margin = new System.Windows.Forms.Padding(2);
            this.slika2.Name = "slika2";
            this.slika2.Size = new System.Drawing.Size(61, 64);
            this.slika2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.slika2.TabIndex = 3;
            this.slika2.TabStop = false;
            this.slika2.Tag = "z_ozadjem";
            // 
            // ozadje
            // 
            this.ozadje.Image = global::Premikajoce_ozadje.Properties.Resources.background;
            this.ozadje.Location = new System.Drawing.Point(5, 6);
            this.ozadje.Margin = new System.Windows.Forms.Padding(2);
            this.ozadje.Name = "ozadje";
            this.ozadje.Size = new System.Drawing.Size(2000, 480);
            this.ozadje.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.ozadje.TabIndex = 0;
            this.ozadje.TabStop = false;
            this.ozadje.Click += new System.EventHandler(this.ozadje_Click);
            // 
            // PremikOzadja
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(414, 291);
            this.Controls.Add(this.decek);
            this.Controls.Add(this.slika1);
            this.Controls.Add(this.slika2);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.ozadje);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "PremikOzadja";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.PremikOzadja_Load);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.tipkaDol);
            ((System.ComponentModel.ISupportInitialize)(this.decek)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.slika1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.slika2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ozadje)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox ozadje;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.PictureBox slika2;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.PictureBox slika1;
        private System.Windows.Forms.PictureBox decek;
    }
}

