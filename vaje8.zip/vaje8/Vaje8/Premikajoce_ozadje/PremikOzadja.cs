﻿using System;
using System.Windows.Forms;

namespace Premikajoce_ozadje
{
    public partial class PremikOzadja : Form
    {
        int skok;
        public PremikOzadja()
        {
            InitializeComponent();
            this.KeyPreview = true;
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            //decek.Top = 3;
            ozadje.Left -= 8;
            foreach (Control x in this.Controls)
            {
                if (x.Tag == "z_ozadjem")
                {
                    x.Left -= 8;
                }
               
            }
            
            if (ozadje.Left < (this.Width - ozadje.Width))
            {
                ozadje.Left = 0;
                slika1.Left = 1000;
                slika2.Left = 1500;

                // TODO - manjka premik vseh kontrol, ki se gibajo z ozadjem
                // Zapomniti si, kje so na zacetku
            }
            
                

        }

        private void button1_Click(object sender, EventArgs e)
        {
            timer1.Enabled = true;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            timer1.Enabled = false;
        } 
        private void tipkaDol(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Space)
            {
                decek.Top -= 50;
            }

        }

        private void ozadje_Click(object sender, EventArgs e)
        {

        }

        private void PremikOzadja_Load(object sender, EventArgs e)
        {
            ozadje.Focus();
        }
    }
}
