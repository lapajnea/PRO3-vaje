﻿
namespace Filmi
{
    partial class GlOkno
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(GlOkno));
            this.IzpisPodatkov = new System.Windows.Forms.TextBox();
            this.parametri = new System.Windows.Forms.CheckedListBox();
            this.gmbPrikazi = new System.Windows.Forms.Button();
            this.vnosNaslov = new System.Windows.Forms.TextBox();
            this.vnosLeto = new System.Windows.Forms.TextBox();
            this.vnosReziser = new System.Windows.Forms.TextBox();
            this.vnosCerti = new System.Windows.Forms.TextBox();
            this.vnosDolzina = new System.Windows.Forms.TextBox();
            this.vnosOcena = new System.Windows.Forms.TextBox();
            this.textNaslov = new System.Windows.Forms.Label();
            this.textOcena = new System.Windows.Forms.Label();
            this.textLeto = new System.Windows.Forms.Label();
            this.textReziser = new System.Windows.Forms.Label();
            this.textCerti = new System.Windows.Forms.Label();
            this.textMinute = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // IzpisPodatkov
            // 
            this.IzpisPodatkov.Location = new System.Drawing.Point(564, 26);
            this.IzpisPodatkov.Multiline = true;
            this.IzpisPodatkov.Name = "IzpisPodatkov";
            this.IzpisPodatkov.Size = new System.Drawing.Size(322, 393);
            this.IzpisPodatkov.TabIndex = 0;
            // 
            // parametri
            // 
            this.parametri.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.parametri.FormattingEnabled = true;
            this.parametri.Items.AddRange(new object[] {
            "naslov",
            "leto",
            "reziser",
            "certifikat",
            "dolzina",
            "ocena",
            "opis"});
            this.parametri.Location = new System.Drawing.Point(28, 44);
            this.parametri.Name = "parametri";
            this.parametri.Size = new System.Drawing.Size(84, 124);
            this.parametri.TabIndex = 1;
            // 
            // gmbPrikazi
            // 
            this.gmbPrikazi.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.gmbPrikazi.Location = new System.Drawing.Point(28, 365);
            this.gmbPrikazi.Name = "gmbPrikazi";
            this.gmbPrikazi.Size = new System.Drawing.Size(117, 66);
            this.gmbPrikazi.TabIndex = 2;
            this.gmbPrikazi.Text = "Prikaži";
            this.gmbPrikazi.UseVisualStyleBackColor = false;
            this.gmbPrikazi.Click += new System.EventHandler(this.gmbPrikazi_Click);
            // 
            // vnosNaslov
            // 
            this.vnosNaslov.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.vnosNaslov.Location = new System.Drawing.Point(230, 56);
            this.vnosNaslov.Name = "vnosNaslov";
            this.vnosNaslov.Size = new System.Drawing.Size(120, 20);
            this.vnosNaslov.TabIndex = 3;
            // 
            // vnosLeto
            // 
            this.vnosLeto.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.vnosLeto.Location = new System.Drawing.Point(230, 85);
            this.vnosLeto.Name = "vnosLeto";
            this.vnosLeto.Size = new System.Drawing.Size(120, 20);
            this.vnosLeto.TabIndex = 3;
            // 
            // vnosReziser
            // 
            this.vnosReziser.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.vnosReziser.Location = new System.Drawing.Point(230, 115);
            this.vnosReziser.Name = "vnosReziser";
            this.vnosReziser.Size = new System.Drawing.Size(120, 20);
            this.vnosReziser.TabIndex = 3;
            // 
            // vnosCerti
            // 
            this.vnosCerti.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.vnosCerti.Location = new System.Drawing.Point(319, 222);
            this.vnosCerti.Multiline = true;
            this.vnosCerti.Name = "vnosCerti";
            this.vnosCerti.Size = new System.Drawing.Size(130, 23);
            this.vnosCerti.TabIndex = 3;
            // 
            // vnosDolzina
            // 
            this.vnosDolzina.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.vnosDolzina.Location = new System.Drawing.Point(319, 271);
            this.vnosDolzina.Multiline = true;
            this.vnosDolzina.Name = "vnosDolzina";
            this.vnosDolzina.Size = new System.Drawing.Size(130, 20);
            this.vnosDolzina.TabIndex = 3;
            // 
            // vnosOcena
            // 
            this.vnosOcena.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.vnosOcena.Location = new System.Drawing.Point(145, 315);
            this.vnosOcena.Multiline = true;
            this.vnosOcena.Name = "vnosOcena";
            this.vnosOcena.Size = new System.Drawing.Size(109, 20);
            this.vnosOcena.TabIndex = 3;
            // 
            // textNaslov
            // 
            this.textNaslov.Location = new System.Drawing.Point(137, 56);
            this.textNaslov.Name = "textNaslov";
            this.textNaslov.Size = new System.Drawing.Size(87, 18);
            this.textNaslov.TabIndex = 4;
            this.textNaslov.Text = "Vpišite naslov:";
            // 
            // textOcena
            // 
            this.textOcena.Location = new System.Drawing.Point(29, 303);
            this.textOcena.Name = "textOcena";
            this.textOcena.Size = new System.Drawing.Size(110, 32);
            this.textOcena.TabIndex = 4;
            this.textOcena.Text = "Vpišite oceno:\r\n(od 0.00 do 10.00)\r\n";
            // 
            // textLeto
            // 
            this.textLeto.Location = new System.Drawing.Point(137, 85);
            this.textLeto.Name = "textLeto";
            this.textLeto.Size = new System.Drawing.Size(87, 18);
            this.textLeto.TabIndex = 4;
            this.textLeto.Text = "Vpišite leto:";
            // 
            // textReziser
            // 
            this.textReziser.Location = new System.Drawing.Point(137, 115);
            this.textReziser.Name = "textReziser";
            this.textReziser.Size = new System.Drawing.Size(87, 18);
            this.textReziser.TabIndex = 4;
            this.textReziser.Text = "Vnesite režiserja:";
            // 
            // textCerti
            // 
            this.textCerti.Location = new System.Drawing.Point(29, 183);
            this.textCerti.Name = "textCerti";
            this.textCerti.Size = new System.Drawing.Size(271, 62);
            this.textCerti.TabIndex = 4;
            this.textCerti.Text = "Vpišite certifikat:\r\n(Approved, G, GP, M, NC-17, Not Rated, PG, PG-13, \r\nPassed, " +
    "R, TV-MA, Unrated, X)\r\n";
            // 
            // textMinute
            // 
            this.textMinute.Location = new System.Drawing.Point(29, 260);
            this.textMinute.Name = "textMinute";
            this.textMinute.Size = new System.Drawing.Size(271, 31);
            this.textMinute.TabIndex = 4;
            this.textMinute.Text = "Vpišite dolžino v minutah:\r\n(Izpisali se bodo filmi, ki niso daljši od vpisanih m" +
    "inut)\r\n";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(25, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(199, 26);
            this.label1.TabIndex = 5;
            this.label1.Text = "lzberite, katere lastnosti filma želite videti \r\nter poljubno izpolnite spodnja p" +
    "olja.\r\n";
            // 
            // GlOkno
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(911, 443);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textMinute);
            this.Controls.Add(this.textCerti);
            this.Controls.Add(this.textReziser);
            this.Controls.Add(this.textLeto);
            this.Controls.Add(this.textOcena);
            this.Controls.Add(this.textNaslov);
            this.Controls.Add(this.vnosOcena);
            this.Controls.Add(this.vnosDolzina);
            this.Controls.Add(this.vnosReziser);
            this.Controls.Add(this.vnosCerti);
            this.Controls.Add(this.vnosLeto);
            this.Controls.Add(this.vnosNaslov);
            this.Controls.Add(this.gmbPrikazi);
            this.Controls.Add(this.parametri);
            this.Controls.Add(this.IzpisPodatkov);
            this.Name = "GlOkno";
            this.Text = "POIŠČI FILM";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox IzpisPodatkov;
        private System.Windows.Forms.CheckedListBox parametri;
        private System.Windows.Forms.Button gmbPrikazi;
        private System.Windows.Forms.TextBox vnosNaslov;
        private System.Windows.Forms.TextBox vnosLeto;
        private System.Windows.Forms.TextBox vnosReziser;
        private System.Windows.Forms.TextBox vnosCerti;
        private System.Windows.Forms.TextBox vnosDolzina;
        private System.Windows.Forms.TextBox vnosOcena;
        private System.Windows.Forms.Label textNaslov;
        private System.Windows.Forms.Label textOcena;
        private System.Windows.Forms.Label textLeto;
        private System.Windows.Forms.Label textReziser;
        private System.Windows.Forms.Label textCerti;
        private System.Windows.Forms.Label textMinute;
        private System.Windows.Forms.Label label1;
    }
}

