﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SQLite;
namespace Filmi
{
    public partial class GlOkno : Form
    {

        public GlOkno()
        {
            InitializeComponent();


        }

        /// <summary>
        /// Splošna funkcija ki kliče podatke iz baze podatkov, glede na
        /// vnešen ukaz 
        /// </summary>
        /// <param name="klic"></param>
        public static string[] Funkcija(string klic = "SELECT id, naslov, leto, reziser, certifikat, dolzina, ocena, opis FROM filmi;")
        {
            string niz = @"Data Source=..\..\..\filmi.sqlite; Version=3;";
            SQLiteConnection povezava = new SQLiteConnection(niz);
            povezava.Open(); //odpremo povezavo
            SQLiteCommand ukaz = new SQLiteCommand(); // objekt tipa command
            ukaz.Connection = povezava; // s katero povezavo je povezan
            ukaz.CommandType = CommandType.Text; // tip ukaza
            ukaz.CommandText = klic;

            SQLiteDataReader prebrano = ukaz.ExecuteReader();

            // da dobimo velikost "vrstice"
            int konec = 0;
            int zacetek = 0;
            zacetek = klic.IndexOf("SELECT");
            konec = klic.IndexOf("FROM");
            int velikost = klic.Substring(zacetek + 6, konec - zacetek - 6).Split(',').Length;

            //string[] tabela_podatkov = new string[velikost + 1];
            List<string> tabela = new List<string>();
            int i = 0;

            while (prebrano.Read())
            {
                string vrstica = "";
                for (int j = 0; j < velikost; j++)
                {
                    vrstica += $"{prebrano[j].ToString()}, ";
                }
                tabela.Add(vrstica);
                //tabela_podatkov[i] = vrstica;
                i++;
            }
            povezava.Close();
            return tabela.ToArray();

            
        }

        private void gmbPrikazi_Click(object sender, EventArgs e)
        {
            List<string> izpis = new List<string>();
            foreach (string parameter in parametri.CheckedItems)
            {
                izpis.Add(parameter);
            }

            List<string> pogoji = new List<string>();
            //foreach(Control c in this.Controls)
            //{
            //    if (this.Controls.OfType<TextBox>().Any(t => string.IsNullOrEmpty(t.Text)))
            //    {
            //        pogoji.Add(c.Text);
            //    }
            
            // }

            

            if (!string.IsNullOrEmpty(vnosNaslov.Text))
            {
                pogoji.Add($"naslov LIKE \'%{vnosNaslov.Text}%\' ");
            }

            if (!string.IsNullOrEmpty(vnosLeto.Text))
            {
                pogoji.Add($"leto LIKE \'%{vnosLeto.Text}%\'");
            }

            if (!string.IsNullOrEmpty(vnosReziser.Text))
            {
                pogoji.Add($"reziser LIKE \'%{vnosReziser.Text}%\' ");
            }

            if (!string.IsNullOrEmpty(vnosCerti.Text))
            {
                pogoji.Add($"certifikat LIKE \'%{vnosCerti.Text}%\' ");
            }

            if (!string.IsNullOrEmpty(vnosDolzina.Text))
            {
                pogoji.Add($"dolzina <= {vnosDolzina.Text} ");
            }

            if (!string.IsNullOrEmpty(vnosOcena.Text))
            {
                pogoji.Add($"ocena = {vnosDolzina.Text} ");
            }

            string ukazPogoji = string.Join(",", pogoji);

            // združimo vse
            string ukazKlic = $"SELECT {string.Join(",", izpis)} FROM filmi WHERE {ukazPogoji} ;";
            IzpisPodatkov.Lines = Funkcija(ukazKlic).ToArray();




        }
    }
}
