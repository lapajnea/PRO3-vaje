﻿
namespace Nobel
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.parametriBox = new System.Windows.Forms.CheckedListBox();
            this.comboPredmet = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.textLeto = new System.Windows.Forms.TextBox();
            this.textNobelovec = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.gumb = new System.Windows.Forms.Button();
            this.izpis = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // parametriBox
            // 
            this.parametriBox.FormattingEnabled = true;
            this.parametriBox.Items.AddRange(new object[] {
            "leto",
            "predmet",
            "dobitnik"});
            this.parametriBox.Location = new System.Drawing.Point(254, 52);
            this.parametriBox.Name = "parametriBox";
            this.parametriBox.Size = new System.Drawing.Size(103, 49);
            this.parametriBox.TabIndex = 1;
            // 
            // comboPredmet
            // 
            this.comboPredmet.FormattingEnabled = true;
            this.comboPredmet.Items.AddRange(new object[] {
            "KEMIJA",
            "LITERATURA",
            "EKONOMIJA",
            "MEDICINA",
            "MIR",
            "FIZIKA",
            ""});
            this.comboPredmet.Location = new System.Drawing.Point(43, 52);
            this.comboPredmet.Name = "comboPredmet";
            this.comboPredmet.Size = new System.Drawing.Size(103, 21);
            this.comboPredmet.TabIndex = 3;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(40, 23);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(168, 13);
            this.label1.TabIndex = 4;
            this.label1.Text = "Izberite kater predmet vas zanima.";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(40, 88);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(150, 13);
            this.label2.TabIndex = 5;
            this.label2.Text = "Vpišite katero leto vas zanima.";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(40, 152);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(162, 13);
            this.label3.TabIndex = 6;
            this.label3.Text = "Vpišite ime ali priimek nobelovca ";
            // 
            // textLeto
            // 
            this.textLeto.Location = new System.Drawing.Point(43, 116);
            this.textLeto.Name = "textLeto";
            this.textLeto.Size = new System.Drawing.Size(120, 20);
            this.textLeto.TabIndex = 7;
            // 
            // textNobelovec
            // 
            this.textNobelovec.Location = new System.Drawing.Point(43, 178);
            this.textNobelovec.Name = "textNobelovec";
            this.textNobelovec.Size = new System.Drawing.Size(120, 20);
            this.textNobelovec.TabIndex = 7;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(251, 23);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(147, 13);
            this.label4.TabIndex = 8;
            this.label4.Text = "Izberite kar želite da se izpiše.";
            // 
            // gumb
            // 
            this.gumb.Location = new System.Drawing.Point(248, 150);
            this.gumb.Name = "gumb";
            this.gumb.Size = new System.Drawing.Size(108, 47);
            this.gumb.TabIndex = 9;
            this.gumb.Text = "prikaži";
            this.gumb.UseVisualStyleBackColor = true;
            this.gumb.Click += new System.EventHandler(this.gumb_Click);
            // 
            // izpis
            // 
            this.izpis.Location = new System.Drawing.Point(422, 39);
            this.izpis.Multiline = true;
            this.izpis.Name = "izpis";
            this.izpis.Size = new System.Drawing.Size(214, 190);
            this.izpis.TabIndex = 10;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(665, 258);
            this.Controls.Add(this.izpis);
            this.Controls.Add(this.gumb);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.textNobelovec);
            this.Controls.Add(this.textLeto);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.comboPredmet);
            this.Controls.Add(this.parametriBox);
            this.Name = "Form1";
            this.Text = "NOBELOVCI";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.CheckedListBox parametriBox;
        private System.Windows.Forms.ComboBox comboPredmet;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textLeto;
        private System.Windows.Forms.TextBox textNobelovec;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button gumb;
        private System.Windows.Forms.TextBox izpis;
    }
}

