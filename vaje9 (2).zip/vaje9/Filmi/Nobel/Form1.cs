﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Npgsql;
namespace Nobel
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }


        /// <summary>
        /// s to funkcijo bomo pokliclai ukaze
        /// </summary>
        /// <param name="sqlUkaz"></param>
        /// <returns></returns>
        public static string[] Funkcija(string sqlUkaz = "SELECT * FROM nobel;")
        {
            // povezovalni niz
            string povNiz = "Server= baza.fmf.uni-lj.si; User Id= student11; Password= student; Database= nobel2012;";
            //povezava s pomočjo NPpgsql
            NpgsqlConnection pov = new NpgsqlConnection(povNiz);
            pov.Open();

            NpgsqlCommand ukaz = new NpgsqlCommand();
            ukaz.Connection = pov;
            ukaz.CommandType = CommandType.Text;
            ukaz.CommandText = sqlUkaz;

            NpgsqlDataReader rez = ukaz.ExecuteReader();

            List<string> tabela = new List<string>();
            while (rez.Read())
            {
                for (int i = 0; i < rez.VisibleFieldCount; i++)
                {
                    string izp = rez[i].ToString();
                    tabela.Add(izp + " : ");
                }
            }
            pov.Close();
            return tabela.ToArray();
        
        }

        private void gumb_Click(object sender, EventArgs e)
        {

            //preverimio če je chechbox prazen
            var spremeniParameter = new Dictionary<string, string>()
            {
                {"leto", "yr" },
                {"predmet", "subject" },
                {"dobitnik", "winner" }
             
        };

            List<string> tabelaSELECT = new List<string>();

            foreach (string parameter in parametriBox.CheckedItems)
            {
                tabelaSELECT.Add(spremeniParameter[parameter]);
            }

            if (tabelaSELECT.Count == 0)
                MessageBox.Show("Izbrati morate, kar si želite, da se prikaže!");



            string ukazSELECT = string.Join(",", tabelaSELECT); // za SELECT

            // preverimo pogoje za where 

            List<string> tabelaWHERE = new List<string>();
            string ukazWHERE;
            if (!string.IsNullOrEmpty(textLeto.Text))
            {
                tabelaWHERE.Add($"yr LIKE \'%{textLeto.Text}%\' ");
            }

            if (!string.IsNullOrEmpty(textNobelovec.Text))
            {
                tabelaWHERE.Add($"winner LIKE \'%{textNobelovec.Text}%\' ");
            }


            var spremeniPredmet = new Dictionary<string, string>()
            {
                {"KEMIJA", "Chemistry" },
                {"EKONOMIJA", "Economics" },
                {"LITERATURA", "Literature" },
                {"MEDICINA", "Medicine" },
                {"MIR", "Peace" },
                {"FIZIKA", "Physics" }

        };

            string izbranPredmet = comboPredmet.Text;
            string predmet = spremeniPredmet[izbranPredmet];

            tabelaWHERE.Add($"subject LIKE \'%{predmet}%\' ");

            ukazWHERE = string.Join(",", tabelaWHERE);
            // združimo pogoje

            string ukazKlic = $"SELECT {string.Join(",", ukazSELECT)} FROM nobel WHERE {ukazWHERE} ;";
            izpis.Lines = Funkcija(ukazKlic).ToArray();
        }
    }
}
